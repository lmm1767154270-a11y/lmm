Phonics Adventure V4.2 真人单词录音批量收集工具
==============================================
1. 上传本 ZIP 到你的 GitHub lmm 仓库根目录，名字保留 PhonicsAdventureV42_auto_voice_source.zip。
2. 在 .github/workflows/build-apk.yml 编辑并替换为 build-apk-v42-human-audio.yml 内容。
3. 进入 Actions 手动触发 Build Phonics APK with Human Word Audio。
4. Github Actions 将尝试从 Wikimedia Commons 收集525个词的 En-us-*.ogg/oga/mp3 候选真人录音，仅保留许可可核对的文件。
5. 产物有 phonics-us-word-audio-candidates（包含候选单词录音、授权记录、缺失清单）及 PhonicsAdventure-v42-human-audio-debug（重新打包 APK）。
6. 重要：收集到不表示已人工审核，必须试听确认真人人声、美式口音、读音与词义；缺失录音不会合成补齐。
7. 英文解释和完整例句是此 App 的自定义文本，Wikimedia 通常没有完全相同的录音。必须请真人录制，然后命名 definition_cat.mp3、sentence_cat.mp3 等，和词库CSV对应。
8. 可以把额外授权真人录音打成 human_recordings.zip，上传到 GitHub 仓库根目录，再重新运行此工作流，即可自动打入 APK（不必手机里逐条导入）。
9. 仅录制真实授权的人声，勿把自动合成发音标注为真人录音。使用 Commons 录音应遵守每段具体授权条件与署名要求。
10. 本工具源码已静态测试，但当前环境无法连到 Wikimedia 外网或运行安卓模拟器，所以具体能获取多少录音，取决于云端请求结果与资源许可。下载失败时请在 Actions 的日志和覆盖率 CSV 核查，不要假定525词已配齐。

此 APK 使用独立 applicationId（com.phonics.adventure.v42batch），可与原 V4.2 并存，避免 GitHub 每次生成的 debug 签名不同导致覆盖安装失败。不会继承旧版里单独导入的 cat 录音。
