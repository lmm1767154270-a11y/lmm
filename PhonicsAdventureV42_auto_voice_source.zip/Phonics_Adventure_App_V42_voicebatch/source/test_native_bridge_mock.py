"""UI bridge smoke test via native mock. Android actual import requires handset test."""
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
html=(root/'Phonics_Adventure_V4_离线试玩.html').read_text('utf-8')
# Stub behaves like JavaScriptInterface: import request and native file availability.
mock='''<script>window.__selected=[];window.__clips={};window.NativeAudio={hasClip:(k)=>!!window.__clips[k], requestImport:(k)=>window.__selected.push(k), requestBulkImport:()=>window.__selected.push("bulk"),playClip:(k)=>window.__selected.push("play:"+k)};</script>'''
html=html.replace('</head>',mock+'</head>')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844})
 errors=[]
 page.on('pageerror',lambda e: errors.append(str(e)))
 page.set_content(html,wait_until='load')
 page.locator('[data-family="short_-at"]').click()
 page.locator('[data-activity="cards"]').click()
 assert page.locator('button[data-native-import="word:cat"]').count()==1
 page.locator('button[data-native-import="word:cat"]').click()
 assert page.evaluate('window.__selected[0]')=='word:cat'
 page.evaluate('window.__clips["word:cat"]=true;window.onNativeAudioEvent("imported","录音已保存，正在试听","word:cat")')
 page.wait_for_timeout(350)
 assert page.locator('text=✅ 已有真人录音').count()>=1
 assert 'play:word:cat' in page.evaluate('window.__selected')
 page.locator('[data-go="home"]').first.click()
 page.locator('button[data-go="settings"]').click()
 page.locator('#nativeBulkAudioImport').click()
 assert 'bulk' in page.evaluate('window.__selected')
 assert not errors,errors
 browser.close()
print('PASS native bridge UI clicks, imported callback, audio replay, and settings bulk import. Android device untested.')
