#!/usr/bin/env python3
"""Download candidate human U.S. English word recordings from Wikimedia Commons.

Run in GitHub Actions. No speech synthesis. Only exact-file matches with a
recognized free license are downloaded. Every file still needs a human review
for accent, sound quality, and meaning. Keep credits for every clip.
"""
from __future__ import annotations
import csv, html, json, re, time, urllib.parse, urllib.request, urllib.error, zipfile
from html.parser import HTMLParser
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BANK=json.loads((ROOT/'wordbank.json').read_text(encoding='utf-8'))
WORDS=sorted(BANK['words'])
OUT=ROOT/'voice_pack'
OUT.mkdir(exist_ok=True)
API='https://commons.wikimedia.org/w/api.php'
AGENT='PhonicsAdventureVoiceCollector/1.0 (educational; https://github.com/lmm1767154270-a11y/lmm)'
EXTS=['ogg','oga','mp3']
ALLOWED={'cc0','public domain','pd','cc by','cc by-sa'}
class Stripper(HTMLParser):
 def __init__(self):super().__init__();self.parts=[]
 def handle_data(self,data):self.parts.append(data)
def strip_html(s):
 p=Stripper();p.feed(str(s or ''));return ' '.join(''.join(p.parts).split())
def field(meta,key):return strip_html((meta.get(key) or {}).get('value',''))
def accepted(license_name):
 s=' '.join(license_name.lower().replace('_',' ').replace('-',' ').split())
 if s.startswith('cc0') or 'public domain' in s or s=='pd':return True
 if re.match(r'^cc by( sa)?( [0-9.]+)?$',s):return True
 return False

def urlread(url,limit=4_000_000):
 req=urllib.request.Request(url,headers={'User-Agent':AGENT,'Accept':'application/json, audio/ogg, audio/mpeg, */*'})
 last=None
 for attempt in range(3):
  try:
   with urllib.request.urlopen(req,timeout=45) as res:
    payload=res.read(limit+1)
    if len(payload)>limit:raise ValueError('remote file is too large')
    return payload
  except (urllib.error.URLError,TimeoutError) as ex:
   last=ex;time.sleep(2**attempt)
 raise RuntimeError(str(last))

def batches(items,n):
 for i in range(0,len(items),n):yield items[i:i+n]

def lookup(titles):
 params=urllib.parse.urlencode({'action':'query','format':'json','formatversion':'2','prop':'imageinfo','iiprop':'url|extmetadata','titles':'|'.join('File:'+t for t in titles)})
 data=json.loads(urlread(API+'?'+params,1_700_000).decode('utf-8'))
 return {p['title'].removeprefix('File:').lower():p for p in data.get('query',{}).get('pages',[])}

def run():
 reports={w:{'word':w,'status':'not_found','file':'','license':'','source':'','note':''} for w in WORDS}
 credits=[]; total=0
 # Query in batches so Commons API stays below its per-request title limit.
 titles=[f'En-us-{w}.{ext}' for w in WORDS for ext in EXTS]
 pages={}
 for group in batches(titles,45):
  try:pages.update(lookup(group))
  except Exception as exc:
   print('Metadata query unavailable:',str(exc)[:180])
  time.sleep(0.15)
 for index,w in enumerate(WORDS):
  existing=[p for p in OUT.glob('word_'+w+'.*') if p.suffix.lower() in ('.ogg','.oga','.mp3')]
  if existing:
   reports[w].update(status='already_provided',file=existing[0].name)
   continue
  choices=[]
  for ext in EXTS:
   p=pages.get(f'En-us-{w}.{ext}'.lower())
   if not p or 'imageinfo' not in p:continue
   info=p['imageinfo'][0];meta=info.get('extmetadata',{})
   lic=field(meta,'LicenseShortName')
   if not accepted(lic):
    reports[w].update(status='license_unverified',note=lic)
    continue
   url=info.get('url','')
   if urllib.parse.urlparse(url).hostname!='upload.wikimedia.org':continue
   choices.append((ext,info,lic,meta,p['title']))
  if not choices:continue
  ext,info,lic,meta,title=choices[0]
  dest=OUT/f'word_{w}.{ext}'
  try:
   contents=urlread(info['url'],4_000_000)
   if len(contents)<100:raise ValueError('tiny or empty audio')
   dest.write_bytes(contents)
   page='https://commons.wikimedia.org/wiki/'+urllib.parse.quote(title.replace(' ','_'))
   entry={'word':w,'local_file':dest.name,'source_filename':title,'source_page':page,
    'license':lic,'license_url':field(meta,'LicenseUrl'),
    'attribution':field(meta,'Artist') or field(meta,'Credit') or '(see Commons file page)',
    'human_verified':False}
   credits.append(entry)
   reports[w].update(status='downloaded_needs_human_review',file=dest.name,license=lic,source=page)
   total+=1
  except Exception as exc:reports[w].update(status='download_error',note=str(exc)[:180])
  if index%50==0:print(f'Processed {index+1} / {len(WORDS)} words; candidate audio: {total}')
 # Keep attribution within the APK and the downloadable artifact.
 (OUT/'credits.json').write_text(json.dumps(credits,indent=2,ensure_ascii=False),encoding='utf-8')
 with (ROOT/'word_audio_coverage.csv').open('w',newline='',encoding='utf-8-sig') as f:
  writer=csv.DictWriter(f,fieldnames=['word','status','file','license','source','note']);writer.writeheader();writer.writerows(reports.values())
 with (ROOT/'word_audio_attribution.csv').open('w',newline='',encoding='utf-8-sig') as f:
  writer=csv.DictWriter(f,fieldnames=['word','local_file','source_filename','source_page','license','license_url','attribution','human_verified']);writer.writeheader();writer.writerows(credits)
 archive=ROOT/'candidate_us_word_audio.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(OUT.iterdir()):
   if p.suffix.lower() in ('.ogg','.oga','.mp3'):z.write(p,p.name)
  z.write(ROOT/'word_audio_coverage.csv','word_audio_coverage.csv')
  z.write(ROOT/'word_audio_attribution.csv','word_audio_attribution.csv')
 print('Candidate US word audio downloaded:',total,'out of',len(WORDS),'(NOT YET HUMAN VERIFIED)')
 print('Definitions and sample sentences require separately recorded human audio.')
 print('Output:',archive)
if __name__=='__main__':run()
