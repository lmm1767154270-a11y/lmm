# -*- coding:utf-8 -*-
"""Build self-contained offline game + Android assets, optional licensed human recordings.
Audio: record files into source/voice_pack/ as word_cat.mp3, praise_1.mp3, etc.
Only local files are packed. Never generate synthetic audio.
"""
import pathlib, base64, json, mimetypes
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT.parent/'Phonics_Adventure_V4_离线试玩.html'
ANDROID_OUT=ROOT.parent/'android-app'/'app'/'src'/'main'/'assets'/'index.html'

def data_url(path):
 path=pathlib.Path(path)
 typ=mimetypes.guess_type(path.name)[0] or ('image/webp' if path.suffix=='.webp' else 'application/octet-stream')
 if path.suffix.lower()=='.ogg':typ='audio/ogg'
 if path.suffix.lower()=='.m4a':typ='audio/mp4'
 return 'data:'+typ+';base64,'+base64.b64encode(path.read_bytes()).decode('ascii')

assets={'avatars':{name:data_url(ROOT/'assets'/f'{name}.png') for name in ('ruby','pip','nova')},'words':{w:data_url(ROOT/'assets'/f'{w}.webp') for w in ('dip','sip','zip','lip','tip','rip','chip','ship','trip','flip','clip','hip')},'humanAudio':{}}
record_dir=ROOT/'voice_pack'
if record_dir.is_dir():
 for audio in sorted(record_dir.iterdir()):
  if audio.suffix.lower() not in ('.mp3','.m4a','.ogg','.wav','.aac'):continue
  parts=audio.stem.split('_',1)
  if len(parts)!=2 or parts[0] not in ('word','definition','sentence','praise'):
   import re
   m=re.fullmatch(r'en[-_]us[-_]([a-z]+)',audio.stem,re.I)
   if not m:continue
   key='word:'+m[1].lower()
  else:key=parts[0]+':'+parts[1].lower()
  assets['humanAudio'][key]=data_url(audio)

credits_file=record_dir/'credits.json'
if credits_file.exists():
 try:assets['voiceCredits']=json.loads(credits_file.read_text(encoding='utf-8'))
 except (ValueError,OSError):assets['voiceCredits']=[]
bank=json.loads((ROOT/'wordbank.json').read_text(encoding='utf-8'))
if 'metadata' in bank:bank['metadata']['humanAudioWordCount']=sum('word:'+w in assets['humanAudio'] for w in bank['words'])
html=(ROOT/'app.template.html').read_text(encoding='utf-8')
for key,content in [('__CSS__',(ROOT/'styles.css').read_text(encoding='utf-8')),('__JS__',(ROOT/'app.js').read_text(encoding='utf-8')),('__BANK_JSON__',json.dumps(bank,ensure_ascii=False,separators=(',',':'))),('__ASSETS_JSON__',json.dumps(assets,ensure_ascii=False,separators=(',',':')) )]:
 html=html.replace(key,content.replace('</script>','<\\/script>') if key in ('__JS__','__BANK_JSON__','__ASSETS_JSON__') else content)
assert all(x not in html for x in ('__CSS__','__JS__','__BANK_JSON__','__ASSETS_JSON__'))
OUT.write_text(html,encoding='utf-8')
ANDROID_OUT.parent.mkdir(parents=True,exist_ok=True)
ANDROID_OUT.write_text(html,encoding='utf-8')
print('Built:',OUT,'size:',OUT.stat().st_size,'bytes')
print('Android asset:',ANDROID_OUT)
print('Words:',len(bank['words']),'Playable patterns:',sum(x['status']=='ready' for x in bank['families']),'Human audio bundled:',len(assets['humanAudio']))
