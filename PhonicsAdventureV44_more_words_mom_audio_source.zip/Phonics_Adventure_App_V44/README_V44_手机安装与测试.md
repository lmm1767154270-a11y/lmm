# Phonics Adventure V4.4 — 扩充词库＋全关卡单词听音＋妈妈脚本就近显示

## 已完成
- 887 个唯一英文单词（V4.3有525个，新增362个）；175 个可玩拼读分组。
- r 控制元音 ar：4 → 27 词，包括 car, star, farm, park, jar, bar, arm, art, card, hard, barn, shark, garden 等。
- 对其中130个现有分组补充了词汇；少数规律缺少适龄高频词，不强行加生僻词。
- 所有关卡提供单词听音（与 Flip & Discover 共用同一批真人录音）：押韵、拼读规律、图片配对、拼写、句子选择、句子积木。
- 一段完整句子用安卓系统美式英语 AI 朗读；句子积木中的非重点功能词可用AI朗读，**目标拼读词不会用AI冒充真人**。
- 妈妈英语照读脚本始终显示，不需再展开；位置紧贴当前题目，在答案上方。
- 保持独立安卓原生音频导入支持：录音文件保存在当前 App 的私有目录。

## 当前限制
- ZIP 未预装887词真人录音。GitHub Actions 会尝试从 Wikimedia Commons 收集有明确授权的候选真人美式录音，但无法保证全部成功或全部通过真人试听核验。
- 未收集到真人录音的词会显示缺录音提醒；不会静默切换成合成词音。
- 只有 -ip 的12张卡是专门绘制的插画，其余词卡使用对应emoji图像标记。
- 此处只测试过浏览器触屏、JavaScript及词库有效性；安卓 APK 仍需通过用户自己的 GitHub Actions 编译和真机检查。

## 手机 GitHub 构建
1. 下载 `PhonicsAdventureV44_more_words_mom_audio_source.zip` 并上传到原仓库根目录（不解压）。
2. 打开 `.github/workflows/build-apk.yml`，进入 Edit file，**只替换代码内容**为 `build-apk-v44.yml`，保存到 `main`。
3. Actions → `Build Phonics APK V4.4` → Run workflow。
4. 成功后打开本次最新运行记录，Artifacts 中下载 `PhonicsAdventure-v44-debug`。
5. APK 装好后在设置里试听英文解释和鼓励，再挑有真人录音的词测试所有玩法的🔊。

## 源码说明
- `source/wordbank.json` 数据库；`source/wordbank_v43_backup.json` 上版备份；`source/expand_v44.py` 增量词库来源。
- `source/app.js` 事件与游戏逻辑；`source/styles.css` 手机界面；`source/build.py` 离线HTML和APK资产生成。
- `source/test_v44.py` 浏览器触屏回归测试；`source/audit_v4.py` 词库审计。
- `source/voice_pack` 存放合法真人录音，手动导入到 V4.4 需重新导一次。
