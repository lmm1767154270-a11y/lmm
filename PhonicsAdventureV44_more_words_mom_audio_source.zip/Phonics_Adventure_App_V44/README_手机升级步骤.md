# Phonics Adventure V4.2 — Android 原生录音导入修复

本版只修复录音导入/保存/播放，没有修改525词词库和原有游戏。

## 核心改进

- 单词卡的“选择真人录音”按钮现在直接调用安卓文件选择器（ACTION_OPEN_DOCUMENT）。
- 选中 OGG/MP3 后，安卓 ContentResolver 把文件复制到 App 内部私有目录，避免 WebView 的 IndexedDB / blob URL 兼容性问题。
- 播放时使用原生 Android MediaPlayer，不再依赖浏览器 `<audio>` 读取本地 OGG。
- 导入成功会显示状态并尝试自动试听；失败会显示具体错误（如文件格式、读取或音频编码）。
- 设置中支持多选录音；支持 `En-us-cat.ogg`、`word_cat.mp3`、`definition_cat.ogg` 等命名。
- 改用独立软件名称 Phonics V4.2 和应用包名 com.phonics.adventure.v42，可与 V4.1 共存。

## 手机上上传 GitHub 并生成 APK

1. 把 `PhonicsAdventureV42_native_source.zip` 上传到现有 GitHub 仓库 `lmm` 的根目录。
2. 编辑 `.github/workflows/build-apk.yml`，替换为 `build-apk-v42.yml` 的全部内容。
3. Actions → Build Phonics APK V4.2 → Run workflow，进入**最新一次**的运行记录。
4. 编译绿勾后从 Artifacts 下载 `PhonicsAdventure-v42-debug`，解压获得 `app-debug.apk`，安装。
5. 打开新图标 **Phonics V4.2** → Word Family Rescue → -at → Flip & Discover → cat → 📁 选择真人录音。
6. 选择之前下载的 `En-us-cat.ogg`；应出现“录音已保存，正在试听”，之后再点 Listen。

## 重要限制

这里没有设备编译环境，不能宣称已实际在你的手机测试成功。如果 V4.2 仍失败，请截取界面显示的**具体错误文字**。

本修复**不含真人录音**，没有配音的项目仍然静音。录音请使用自己录制或已经取得授权的素材。安卓 11+ 的文件选择器和 .ogg 播放需在真实机型验证。


## V4.4 · 新增（2026-11-17）
- 游戏保持旧版结构，现收录887个不重复单词（新增362个）和175个可玩分组。
- 音频按钮出现在所有游戏：图片配对、押韵、拼读规律辨认、拼写、句子理解、句子积木。点击小喇叭不会自动提交答案。
- 妈妈照读内容默认展开，显示在练习题目下方、答案区域上方；翻卡页靠近单词卡上方。
- 真人单词语音 **不保证齐全**：只有授权录音实际收集/导入后才能播放。英文解释、整句和奖励语音使用离线系统英语TTS。
- 安装名 Phonics V4.4；旧版的家长自行导入的录音不会自动跨App迁移。

**更新：** 上传 PhonicsAdventureV44_more_words_mom_audio_source.zip 到 GitHub 仓库根目录，把 .github/workflows/build-apk.yml 替换为本次 build-apk-v44.yml，再手动运行 Actions。
