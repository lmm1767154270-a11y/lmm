#!/usr/bin/env python3
"""Reviewed high-utility phonics expansion for ages ~4-6.
Only explicitly mapped words are added. No automatically invented meanings.
For advanced words, phoneme-count tasks are intentionally disabled until reviewed.
"""
from pathlib import Path
import json, collections, re
ROOT=Path(__file__).resolve().parent
BANK=ROOT/'wordbank.json'
data=json.loads(BANK.read_text(encoding='utf-8'))
# word | emoji | child-friendly English explanation | natural short example
RAW=r'''
alphabet|🔤|All the letters used in a language.|Let's sing the alphabet.

span|🌉|The distance from one end to the other.|The bridge has a long span.
chase|🏃|Run after someone or something.|The puppy likes to chase the ball.
cheese|🧀|A food made from milk.|I like cheese on toast.
cherry|🍒|A small round red fruit.|A cherry is sweet.
chicken|🐔|A farm bird that lays eggs.|The chicken is on the farm.
close|🚪|Shut something.|Close the door gently.
date|📅|A day on the calendar.|What is today's date?
elephant|🐘|A huge animal with a long trunk.|The elephant has big ears.
face|🙂|The front of your head with your eyes and mouth.|Wash your face.
huge|🐘|Very, very big.|That elephant is huge.
jog|🏃|Run slowly for exercise.|Let's jog to the tree.
joke|😂|Something funny that makes people laugh.|Tell me a funny joke.
lunch|🥪|A meal eaten around the middle of the day.|We eat lunch together.
mule|🐴|An animal related to a horse and a donkey.|The mule carries bags.
orange|🍊|A sweet citrus fruit or a color.|Peel the orange.
pencil|✏️|A tool used for drawing and writing.|Use a pencil to draw.
place|📍|A location or a space.|This is a nice place to play.
question|❓|Something you ask to learn more.|Ask me one question.
quilt|🛏️|A thick, soft bed cover.|The quilt is warm.
race|🏁|A contest to see who is fastest.|Let's have a running race.
safe|🛡️|Not in danger.|Hold my hand to stay safe.
shade|🌳|A darker place away from bright sunlight.|Sit in the shade.
shadow|👤|A dark shape made when light is blocked.|My shadow is on the wall.
shape|🔷|The form or outline of something.|A square is a shape.
shelf|📚|A flat place to hold books or toys.|Put the book on the shelf.
snap|🫰|Make a quick sharp sound or break suddenly.|Snap your fingers.
space|🚀|The area beyond Earth or an empty place.|The rocket goes into space.
strong|💪|Having a lot of strength.|The horse is strong.
take|🤲|Pick up or carry something with you.|Take your bag.
thing|📦|An object or something you talk about.|What is that thing?
three|3️⃣|One more than two.|I have three apples.
trap|🪤|Something that catches or holds something.|The toy mouse is in a trap.
what|❓|A word used to ask about something.|What is in the box?
where|📍|A word used to ask about a place.|Where is my hat?
which|👉|A word used when choosing between things.|Which book do you want?
while|⌛|During the time something happens.|Sing while we play.
flat|🪵|Smooth and level, not bumpy.|The floor is flat.
pat|✋|Touch gently with your hand.|Pat the puppy softly.
spat|💬|The past tense of spit; something came out of a mouth.|The baby spat out the food.
splat|💦|A sound when something wet hits a surface.|Splat! The mud hit the ground.
plan|📝|An idea for what you will do.|We have a plan for today.
scan|🔎|Look carefully over something.|Scan the picture for clues.
tan|🟤|A light brown color.|The bag is tan.
gap|↔️|An empty space between two things.|There is a gap in the fence.
slap|✋|Hit with an open hand.|Please do not slap the table.
flap|🐦|Move wings up and down.|Birds flap their wings.
scrap|🧩|A small leftover piece.|Keep this scrap of paper.
strap|🎒|A long strip used to hold something.|The bag has a long strap.
bad|🙁|Not good or not nice.|That was a bad idea.
glad|😊|Happy about something.|I am glad you came.
had|📦|The past tense of have.|I had a toy car.
when|⏰|A word asking about time.|When will we play?
then|➡️|After that time.|First wash, then dry.
men|👥|More than one man.|The men are talking.
get|🎁|Receive or go and take something.|Get your blue bag.
let|🙌|Allow something to happen.|Let me try.
set|🧺|Put something in a place.|Set the cup here.
met|🤝|Saw or knew someone for the first time.|I met a new friend.
yet|⏳|Up to this moment.|Are we there yet?
bet|🎲|Make a guess about what will happen.|I bet it will rain.
fed|🐥|Gave food to someone or an animal.|We fed the ducks.
led|🚶|Showed others the way.|She led the line.
shed|🏠|A small building for keeping things.|The tools are in the shed.
spread|🧈|Move something across an area.|Spread the jam on bread.
twig|🌿|A small, thin branch.|The bird found a twig.
gig|🎤|A short music show or job.|The band has a gig.
grip|✊|Hold something tightly.|Keep a good grip on the rope.
thin|📏|Not thick or wide.|This book is thin.
grin|😄|A big happy smile.|Give me a big grin.
shin|🦵|The front part of your lower leg.|My shin is under my knee.
pit|🕳️|A big hole in the ground.|There is a pit in the sand.
lit|💡|Made bright with light.|The room was lit.
grit|🪨|Tiny bits of sand or stone.|There is grit on my shoe.
spit|💦|Send liquid out of your mouth.|Spit the toothpaste into the sink.
split|✂️|Divide into two or more pieces.|Split the paper into two parts.
quit|🚪|Stop doing something.|Do not quit trying.
brick|🧱|A hard block used to build walls.|This wall is made of bricks.
trick|🎩|A clever or surprising action.|Watch my magic trick.
stick|🪵|A thin piece of wood.|Pick up the stick.
chick|🐣|A baby chicken.|The chick is yellow.
click|🖱️|Make a short sharp tapping sound.|Click the blue button.
shock|⚡|A sudden surprise.|The loud bang gave me a shock.
lock|🔒|Keep a door closed with a key.|Lock the front door.
dock|🚢|A place where boats stop.|The boat is at the dock.
flock|🐦|A group of birds.|A flock of birds flew by.
stock|📦|Things kept ready to use or sell.|The shop has food in stock.
knock|🚪|Tap on a door.|Knock before you come in.
mock|🎭|Copy someone to make fun of them.|It is not kind to mock people.
not|🚫|A word that makes something negative.|That is not my hat.
got|🎁|The past tense of get.|I got a new book.
spot|🐞|A small round mark or a place.|The ladybug has a red spot.
shot|🏀|An attempt to throw a ball at a target.|That was a good shot.
plot|📖|The events in a story.|What is the story plot?
lot|📦|A large number or amount.|We have a lot of blocks.
trot|🐴|Move faster than walking, like a horse.|The pony can trot.
stop|🛑|Do not move or continue.|Stop at the red light.
crop|🌽|Plants grown to be eaten or used.|The farmer grows a crop.
flop|🛋️|Fall or drop heavily.|Flop onto the soft pillow.
plop|💧|Fall with a soft sound.|Plop! The stone fell in.
prop|🎭|An object used in a play.|This hat is a stage prop.
plug|🔌|Something used to connect a device to power.|The plug goes in the socket.
slug|🐌|A soft animal like a snail without a shell.|A slug crawls slowly.
snug|🧣|Warm, cozy, and close-fitting.|The blanket feels snug.
jug|🏺|A container for pouring drinks.|Pour water from the jug.
tug|🪢|Pull something firmly.|Give the rope a little tug.
shrug|🤷|Raise your shoulders to show you do not know.|He gave a little shrug.
spun|🌀|Turned around quickly in the past.|The top spun around.
stun|😮|Surprise someone very much.|The loud sound can stun you.
club|♣️|A group of people who share an interest.|Join our reading club.
shrub|🌳|A small bushy plant.|A bird sits in the shrub.
scrub|🧽|Rub hard to clean something.|Scrub the dirty pan.
tuck|🛏️|Push something neatly into a place.|Tuck the blanket in.
pluck|🐦|Pull something away with a quick movement.|Pluck a leaf from the branch.
cluck|🐔|Make the sound a hen makes.|The hens cluck softly.
chuck|🏀|Throw something casually.|Chuck the ball to me.
stump|🌳|The short part of a tree left in the ground.|Sit beside the tree stump.
thump|🥁|A heavy dull bumping sound.|Thump! I heard the drum.
dump|🚚|Drop or put many things in one place.|Dump the blocks into the box.
clump|🌱|A small group of things close together.|A clump of grass grew here.
yell|📣|Speak very loudly.|Please do not yell indoors.
tell|💬|Give someone information or a story.|Tell me a story.
fell|🍂|Dropped down in the past.|The leaf fell down.
sell|🏪|Give something in exchange for money.|The shop sells fruit.
spell|🔤|Say or write the letters of a word.|Spell your name.
stand|🧍|Be on your feet.|Stand next to the table.
grand|🏰|Very big and impressive.|We saw a grand castle.
brand|🏷️|A name on a kind of product.|This is a new brand.
think|🤔|Use your mind to have an idea.|Think about the answer.
drink|🥛|Take liquid into your mouth and swallow.|Drink some water.
blink|👀|Close and open your eyes quickly.|Blink your eyes twice.
stink|🦨|Smell very bad.|The old socks stink.
shrink|🧥|Become smaller.|This shirt may shrink.
dash|🏃|Run or move very quickly.|Dash to the tree.
mash|🥔|Press food until it becomes soft.|Mash the potatoes.
cash|💵|Money in coins or notes.|We paid with cash.
smash|💥|Break something with force.|The toy car could smash.
track|🛤️|A path or rails for moving along.|The train stays on its track.
stack|🧱|Put things one on top of another.|Stack the blocks high.
crack|🥚|A thin line where something splits.|There is a crack in the egg.
rack|🧥|A frame for holding things.|Hang it on the rack.
blank|⬜|Empty, with nothing written or drawn.|This page is blank.
crank|🔧|A handle that turns.|Turn the toy crank.
rank|🏅|A position in an ordered list.|First is the top rank.
sank|⛵|Went down under water.|The toy boat sank.
chess|♟️|A board game with black and white pieces.|We play chess together.
guess|❓|Say what you think without knowing.|Guess what is inside.
bless|💛|Wish someone happiness or safety.|Bless you after a sneeze.
cast|🎣|Throw a fishing line out.|Cast the line into the water.
blast|💨|A strong burst of air or sound.|A blast of wind blew by.
vast|🌌|Very, very large.|The ocean is vast.
fetch|🐕|Go get something and bring it back.|The dog can fetch a ball.
switch|🔘|Change something or turn it on or off.|Switch on the light.
stretch|🙆|Make your body or something longer.|Stretch your arms up.
hatch|🐣|Come out of an egg.|The chick will hatch.
patch|🩹|A small piece covering or fixing something.|There is a patch on my jeans.
edge|📐|The outside border of something.|Stay away from the table edge.
judge|⚖️|A person who decides things fairly in a court.|The judge listens carefully.
dodge|↔️|Move quickly out of the way.|Dodge the rolling ball.
hedge|🌳|A row of bushes used like a fence.|The hedge is green.
smudge|🖍️|A messy mark made by rubbing.|There is a smudge on the page.
short|📏|Not long or not tall.|This pencil is short.
sport|⚽|A game or activity that uses movement.|Soccer is a sport.
porch|🏠|A covered area outside a door.|Sit on the porch.
north|🧭|The direction at the top of most maps.|The compass points north.
for|🎁|A word showing who receives something.|This gift is for you.
jar|🫙|A container with a wide mouth and a lid.|Put the jam in a jar.
bar|🍫|A long narrow piece of something.|Here is a bar of soap.
far|🏔️|A long way away.|The mountains are far away.
hard|🪨|Not soft or easy to bend.|This rock is hard.
card|💌|A small piece of paper with writing or a picture.|I made a birthday card.
yard|🏡|The outdoor area around a house.|We play in the yard.
barn|🚜|A farm building for animals or crops.|The horse sleeps in the barn.
arm|💪|The part between your shoulder and hand.|Raise your left arm.
art|🎨|Pictures and other creative things people make.|We make art with paint.
part|🧩|One piece of something larger.|This part belongs to the puzzle.
sharp|✏️|Having a pointed edge or tip.|The pencil tip is sharp.
shark|🦈|A large fish with strong jaws.|A shark swims in the sea.
dark|🌃|Having very little light.|The room is dark.
smart|🧠|Good at learning or solving things.|That was a smart idea.
start|🏁|Begin something.|Start at the beginning.
charm|✨|A small pretty object or a pleasing quality.|The bracelet has a charm.
cart|🛒|A small vehicle for carrying things.|Push the shopping cart.
market|🥕|A place where people buy and sell things.|We go to the market.
garden|🌻|A place where flowers or vegetables grow.|Water the garden.
party|🎉|A fun gathering with people.|We have a birthday party.
march|🥁|Walk with regular strong steps.|March with the music.
chart|📊|A picture showing information.|Look at the weather chart.
large|🐘|Big in size.|The elephant is large.
serve|🍽️|Give food or help to someone.|Serve the soup in bowls.
term|📅|A word or a period of time.|This school term is new.
germ|🦠|A tiny living thing that can sometimes make us sick.|Wash away the germs.
person|🧍|One human being.|A person is at the door.
skirt|👗|A piece of clothing worn from the waist.|Her skirt is blue.
third|🥉|The one after second.|She came in third.
first|🥇|Before everyone or everything else.|Go first, then I will go.
stir|🥣|Move a spoon round and round in food.|Stir the soup.
sir|👨|A polite word for a man.|Yes, sir.
dirt|🟤|Soil or earth from the ground.|My shoes have dirt on them.
purse|👛|A small bag used to carry money or things.|The purse is on the chair.
curl|➰|Bend into a curved shape.|Curl the ribbon.
church|⛪|A building used for Christian worship.|The church has a tall roof.
purple|🟣|A color made from red and blue.|The flower is purple.
burst|💥|Break open or come out suddenly.|The bubble may burst.
air|💨|The invisible gas around us that we breathe.|Take a deep breath of air.
fair|⚖️|Treating everyone in a kind and equal way.|Let's take fair turns.
stair|🪜|One step in a staircase.|Step on the next stair.
repair|🔧|Fix something that is broken.|We can repair the toy.
before|⏮️|Earlier than something else.|Wash your hands before eating.
score|🏀|The number of points in a game.|What is the score?
snore|😴|Breathe noisily while sleeping.|I can hear Dad snore.
chore|🧹|A small job done at home.|Putting toys away is a chore.
explore|🧭|Go somewhere to look and discover.|Let's explore the park.
early|🌅|Before the usual time.|We got up early.
heard|👂|The past tense of hear.|I heard a bird sing.
pearl|⚪|A small smooth round gem found in some shells.|The pearl is shiny.
earn|💰|Get something by working.|You can earn a star.
hire|👩‍🔧|Pay someone to do a job.|We can hire a helper.
clear|☀️|Easy to see or understand.|The sky is clear.
dear|💌|Loved or cared about very much.|My dear friend is here.
fear|😟|A feeling of being afraid.|The loud noise gave me fear.
year|🗓️|Twelve months.|A year has twelve months.
gear|⚙️|A toothed wheel or special equipment.|The gears turn together.
cheer|📣|Shout happily to support someone.|Cheer for our team!
beard|🧔|Hair growing on a person's chin.|Grandpa has a beard.
fall|🍂|Move down from a higher place.|Leaves fall in autumn.
call|📞|Say loudly or phone someone.|Call me when you are ready.
hall|🏫|A long space inside a building.|Walk down the hall.
mall|🏬|A big building with many stores.|We went to the mall.
stall|🐴|A small space for an animal or a market shop.|The pony is in a stall.
crawl|🐛|Move low along the ground.|The baby can crawl.
hold|🤲|Keep something in your hand.|Hold my hand.
told|💬|The past tense of tell.|Mom told us a story.
sold|🏪|The past tense of sell.|The shop sold all the apples.
bold|🦁|Brave and willing to try.|That was a bold move.
mold|🧸|A hollow shape used to make something.|Fill the sand mold.
coast|🏖️|The land next to the sea.|We drove along the coast.
ghost|👻|A pretend spooky character in stories.|The story has a friendly ghost.
host|🎤|Someone who welcomes guests.|The host said hello.
roast|🥔|Cook food with dry heat.|We roast potatoes.
bind|📚|Tie things together.|Bind the pages together.
grind|🌾|Break food into very small bits.|Grind the corn into flour.
behind|🙈|At the back of something.|The toy is behind the box.
stalk|🌻|The long stem of a plant.|The flower has a tall stalk.
sidewalk|🚶|A safe path beside a road for people walking.|Walk on the sidewalk.
knit|🧶|Make cloth by looping yarn together.|Grandma can knit a scarf.
know|🧠|Have information in your mind.|I know that word.
knob|🚪|A round handle you can turn.|Turn the door knob.
knight|🛡️|An armored soldier in old stories.|The knight rides a horse.
wrong|❌|Not correct or not right.|That answer is wrong.
wrinkle|〰️|A small line or fold in cloth or skin.|The shirt has a wrinkle.
wreath|🌿|A ring of flowers or leaves.|Hang a wreath on the door.
addition|➕|Putting numbers or things together.|We practice addition with blocks.
vacation|🏝️|A trip or a break from work or school.|We are going on vacation.
motion|🏃|The act of moving.|The swing is in motion.
nation|🌎|A country and its people.|Our nation has many cities.
lotion|🧴|A soft cream used on skin.|Put lotion on dry hands.
future|🚀|The time that has not happened yet.|What will happen in the future?
creature|🐉|An animal or an imagined living thing.|What creature made that sound?
furniture|🪑|Things like tables, beds, and chairs.|The room has wooden furniture.
capture|📷|Catch or record something.|Capture a picture of the rainbow.
little|🐭|Small in size.|This is a little mouse.
bottle|🍼|A container for liquids.|Fill the bottle with water.
bubble|🫧|A little ball of air inside a thin skin.|Blow a big bubble.
middle|↔️|The center of something.|Put the toy in the middle.
puzzle|🧩|A game in which pieces fit together.|Finish the jigsaw puzzle.
kitten|🐱|A young cat.|The kitten is sleeping.
napkin|🧻|Paper or cloth used to wipe your mouth.|Use a napkin after lunch.
muffin|🧁|A small round baked cake.|I ate a blueberry muffin.
button|🔘|A small piece used to fasten clothes or start a device.|Press the red button.
rocket|🚀|A vehicle that can travel into space.|The rocket goes up.
panda|🐼|A black-and-white bear from China.|The panda eats bamboo.
pumpkin|🎃|A large round orange squash.|We made pumpkin soup.
sunset|🌅|The time the sun goes down.|Look at the orange sunset.
bathtub|🛁|A big container you sit in to take a bath.|Fill the bathtub with water.
football|🏈|A ball game played by teams.|We play football outside.
around|🔄|In a circle or in nearby places.|Walk around the tree.
above|⬆️|Higher than something.|The bird flies above us.
again|🔁|One more time.|Let's try again.
away|➡️|To another place or farther from here.|Put the toys away.
animal|🐻|A living creature such as a dog or bear.|A rabbit is an animal.
lemon|🍋|A yellow sour fruit.|The lemon is sour.
paint|🎨|Put color on something with a brush.|Paint a blue sky.
wait|⏳|Stay until something happens.|Wait for your turn.
snail|🐌|A small slow animal with a shell.|The snail is on a leaf.
chain|⛓️|Links joined together.|The bike has a chain.
drain|🚰|Let water flow away.|The water goes down the drain.
brain|🧠|The part inside your head that helps you think.|Your brain helps you learn.
plain|🍞|Simple, without extra things.|I like plain bread.
grain|🌾|A tiny seed used for food.|Rice is a grain.
stain|🧼|A mark that is hard to remove.|There is a stain on my shirt.
main|🛣️|Most important or biggest.|This is the main road.
trail|🥾|A path for walking.|Follow the forest trail.
say|💬|Speak some words.|Say hello to Grandma.
may|🌸|A word for being allowed to do something.|May I come in?
pay|💵|Give money for something.|We pay for the tickets.
way|🛤️|A path or how to do something.|Which way should we go?
gray|🐘|A color between black and white.|The elephant is gray.
clay|🏺|Soft earth you can shape.|Make a bowl from clay.
see|👀|Use your eyes to look.|I see a bird.
free|🕊️|Not trapped or not costing money.|The bird is free.
need|🤲|Must have something.|I need some water.
meet|🤝|Come together with someone.|Let's meet at the park.
keep|📦|Hold onto something for later.|Keep your hat on.
sheep|🐑|A fluffy farm animal.|The sheep says baa.
eat|🍽️|Put food in your mouth and swallow.|Let's eat lunch.
meat|🍗|Food from an animal.|The dog eats some meat.
seat|💺|A place where you sit.|Take your seat.
heat|☀️|Warmth or make something hot.|We feel the heat of the sun.
clean|🧼|Not dirty.|Keep your hands clean.
dream|💭|Pictures or stories in your mind while sleeping.|I had a funny dream.
team|🤝|People playing or working together.|We are on the same team.
bean|🫘|A small seed we eat.|Put a bean in the pot.
each|☝️|Every one by itself.|Give each child a card.
reach|🙌|Stretch to touch something.|Reach for the red ball.
teach|👩‍🏫|Help someone learn.|Mom can teach me words.
soap|🧼|Something you wash with.|Wash with soap.
loaf|🍞|One whole piece of bread.|We bought a loaf of bread.
oak|🌳|A kind of tree that grows acorns.|The oak tree is tall.
float|🛟|Stay on top of water.|The leaf can float.
goal|🥅|The place you try to score in a game.|Kick the ball into the goal.
toad|🐸|An animal like a frog with bumpy skin.|The toad hops away.
coal|🪨|A dark rock people can burn for heat.|Coal is black.
coach|🧑‍🏫|Someone who helps a team learn.|Our coach teaches us soccer.
soak|💧|Put something in water for a while.|Soak the sponge in water.
slow|🐢|Not fast.|The turtle is slow.
show|🎬|Let people see something.|Show me your drawing.
throw|🥎|Send something through the air with your hand.|Throw the ball to me.
window|🪟|Glass in a wall that lets light in.|Look through the window.
pillow|🛏️|A soft cushion for your head.|Put your head on the pillow.
yellow|🟡|The color of a banana.|The sun is bright yellow.
high|⬆️|Far above the ground.|The bird flies high.
tight|🪢|Held firmly with little space.|The lid is tight.
sight|👁️|The ability to see.|What a beautiful sight!
fight|🥊|A struggle or disagreement.|We should not fight.
might|💪|A word meaning something may happen.|It might rain.
flight|✈️|A journey through the air.|Our flight takes off soon.
zoo|🦒|A place where people can see animals.|We went to the zoo.
room|🏠|A space inside a building.|This room is sunny.
cool|🧊|A little cold.|The water feels cool.
noon|🕛|Twelve o'clock in the daytime.|We eat lunch at noon.
boot|🥾|A strong shoe that covers the ankle.|Put on your boots.
broom|🧹|A tool used for sweeping.|Sweep with the broom.
school|🏫|A place where children learn.|I go to school.
tooth|🦷|One hard white part in your mouth.|Brush every tooth.
soon|⏰|After a short time.|We'll be there soon.
good|👍|Nice or right.|That is a good idea.
wood|🪵|Hard material from trees.|This table is made of wood.
foot|🦶|The part at the end of your leg.|My foot is in my shoe.
hood|🧥|A cloth cover for your head.|Put up your hood.
stood|🧍|The past tense of stand.|He stood by the tree.
shook|🫨|The past tense of shake.|The ground shook a little.
hook|🪝|A curved piece for hanging things.|Hang the coat on a hook.
took|🤲|The past tense of take.|I took my bag.
oil|🫗|A slippery liquid used for cooking or machines.|Add a little oil to the pan.
foil|🥡|Thin shiny metal used to wrap food.|Cover the bowl with foil.
spoil|🥛|Become bad or ruin something.|Milk can spoil if left warm.
join|🤝|Come or put together.|Join the two pieces.
voice|🎤|The sound made when you speak or sing.|I hear your voice.
enjoy|😁|Have fun doing something.|Enjoy the game!
annoy|😣|Make someone a little upset.|The buzzing fly may annoy me.
cowboy|🤠|A person who works with cattle.|The cowboy rides a horse.
house|🏡|A building where people live.|This is our house.
out|➡️|Not inside.|Let's go out to play.
shout|📢|Speak very loudly.|Shout for help if needed.
mouth|👄|The part of your face used to eat and speak.|Open your mouth.
south|🧭|The direction opposite north.|The birds fly south.
count|🔢|Say numbers in order.|Count the red blocks.
found|🔍|Discovered or got back something lost.|I found my sock.
ground|🌱|The earth under your feet.|Sit on the ground.
now|⏰|At this time.|Let's go now.
how|❓|A word asking in what way.|How does it work?
wow|😲|A word showing surprise.|Wow! That is big.
down|⬇️|Toward a lower place.|Put the box down.
town|🏘️|A place with homes and shops.|This town is small.
frown|☹️|Make a sad or worried face.|Don't frown; let's try again.
flower|🌼|The colorful part of some plants.|This flower is yellow.
shower|🚿|Water falling from above for washing.|Take a warm shower.
draw|✏️|Make a picture with lines.|Draw a big circle.
straw|🥤|A thin tube for drinking.|Drink through a straw.
dawn|🌅|The time the sun comes up.|Birds sing at dawn.
hawk|🦅|A bird that hunts smaller animals.|A hawk flies high.
dead|🍂|Not alive anymore.|The leaf is dead and dry.
heavy|🏋️|Having a lot of weight.|This bag is heavy.
feather|🪶|A soft covering on a bird.|The feather is light.
weather|🌦️|The sun, rain, wind, and clouds outside.|What's the weather today?
sweat|💦|Water that comes out of skin when hot.|I sweat when I run.
autumn|🍁|The season after summer.|Leaves fall in autumn.
author|✍️|The person who writes a book.|Who is the author?
launch|🚀|Send something off or start it.|Launch the toy rocket.
daughter|👧|A female child in a family.|She is their daughter.
'''
new_data={}
for line in RAW.strip().splitlines():
 if not line.strip() or line.lstrip().startswith('#'):continue
 fields=line.split('|')
 assert len(fields)==4,(len(fields),line)
 w,emoji,definition,sentence=[x.strip() for x in fields]
 assert w.isalpha() and w.isascii() and w.islower(),w
 assert definition.endswith('.') and sentence.endswith(('.', '!', '?')),w
 assert w not in new_data,('duplicate definitions',w)
 new_data[w]={'id':w,'word':w,'emoji':emoji,'definition':definition,'sentence':sentence,'categories':[],'patterns':[],'sounds':[]}
# All groups are explicitly mapped; no matching solely by spelling for ambiguous English patterns.
GROUPS={
'short_-at': 'flat pat spat splat chat that',
'short_-an': 'plan scan tan span',
'short_-ap': 'gap slap flap scrap strap clap trap snap',
'short_-ad': 'bad glad had',
'short_-en': 'when then men',
'short_-et': 'get let set met yet bet',
'short_-ed': 'fed led shed spread',
'short_-ig': 'twig gig',
'short_-in': 'thin grin shin spin skin chin twin',
'short_-it': 'pit lit grit spit split quit',
'short_-ick': 'brick trick stick chick click quick thick',
'short_-og': 'frog jog',
'short_-ot': 'not got spot shot plot lot trot',
'short_-op': 'stop crop drop flop plop prop shop chop',
'short_-ock': 'lock dock flock stock knock shock mock',
'short_-ug': 'plug slug snug jug tug shrug',
'short_-un': 'spun stun',
'short_-ub': 'club shrub scrub',
'short_-uck': 'tuck pluck cluck chuck',
'short_-ump': 'stump thump dump clump',
'short_-ell': 'yell tell fell sell spell smell',
'short_-and': 'stand grand brand',
'short_-ink': 'think drink blink stink shrink',
'short_-ash': 'dash mash cash smash',
'short_-ack': 'track stack crack rack',
'short_-ank': 'blank crank rank sank',
'short_-ess': 'chess guess bless press',
'short_-ast': 'cast blast vast',
'short_-eck': 'check',
'silent_a_e':'take safe late race face place space shape shade wave brave cave save chase snake date plate gate',
'silent_i_e':'five nine ride slide hide smile white bite time',
'silent_o_e':'rose hose close home bone cone phone note joke smoke hope',
'silent_u_e':'mule huge tune cute mute flute',
'silent_-ave':'wave save brave cave',
'silent_-ake':'take snake make cake',
'silent_-ame':'same name game',
'silent_-ane':'plane lane crane',
'silent_-ate':'late plate date gate',
'silent_-ide':'ride slide hide',
'silent_-ine':'nine fine',
'silent_-ite':'white bite kite',
'silent_-ive':'five dive',
'silent_-one':'bone cone phone stone',
'silent_-ope':'hope slope rope',
'silent_-ose':'rose hose nose',
'silent_-une':'tune dune',
'silent_-ute':'flute mute cute',
'vowel_ai':'paint wait snail chain drain brain plain grain stain main trail',
'vowel_ay':'say may pay way gray clay',
'vowel_ee':'see free need meet keep sheep green sleep',
'vowel_ea (long e)':'eat meat seat heat clean dream team bean each reach teach',
'vowel_oa':'soap loaf oak float goal toad coal coach soak',
'vowel_ow (long o)':'slow show throw window pillow yellow',
'vowel_igh':'high tight sight fight might flight',
'vowel_oo (long)':'zoo room cool noon boot broom school tooth soon',
'vowel_oo (short)':'good wood foot hood stood shook hook took',
'vowel_oi':'oil foil spoil join voice',
'vowel_oy':'enjoy annoy cowboy',
'vowel_ou':'house out shout mouth south count found ground',
'vowel_ow (cow)':'now how wow down town frown flower shower',
'vowel_aw':'draw straw dawn hawk crawl',
'vowel_ea (short e)':'dead heavy feather weather sweat spread',
'vowel_au':'autumn author launch daughter',
'vowel_-ail':'snail trail',
'vowel_aw extended':'draw straw dawn',
'vowel_oa extended':'soap loaf soak',
'vowel_igh extended':'high sight',
'vowel_oo (food)':'zoo room boot school soon',
'vowel_ow (snow)':'slow show throw pillow window',
'vowel_ow (cow) extended':'now how down frown',
'vowel_ou extended':'house shout count found ground',
'vowel_oy extended':'enjoy cowboy',
'vowel_oi extended':'oil foil join',
'r_ar':'jar bar far hard card yard barn arm art part sharp shark dark smart start charm cart market garden party march chart large',
'r_or':'short sport porch north for horse more shore store',
'r_er':'serve term germ person',
'r_ir':'skirt third first stir sir dirt',
'r_ur':'purse curl church purple burst',
'r_air':'air fair stair repair',
'r_ore':'before score snore chore explore',
'r_ear (bird)':'early heard pearl earn',
'r_ire':'hire',
'r_air extended':'air fair stair repair',
'r_ar extended':'jar hard card yard barn arm sharp shark dark start cart art',
'r_or extended':'short north porch sport horse',
'r_er extended':'serve term germ',
'r_ir extended':'first third skirt dirt stir',
'r_ur extended':'purse curl church purple',
'digraph_sh':'shark sharp shirt short sheep shout shadow shelf shake wash push brush shell ship shop fish dish',
'digraph_ch':'chair cheese chicken cherry chin chat chop chip lunch beach peach teach',
'digraph_th (voiceless)':'think thin thick three thank mouth south',
'digraph_wh':'when white where what while which',
'digraph_ng':'thing strong bring spring',
'digraph_ck':'lock knock shock rock quick thick check chick trick brick',
'digraph_ph':'elephant alphabet phone photo dolphin',
'digraph_tch':'fetch stretch switch hatch patch scratch',
'digraph_dge':'edge judge dodge hedge smudge',
'digraph_th (voiced)':'then that these those this weather feather',
'digraph_qu':'quit quilt queen quick quiet quack question',
'blend_bl':'blink blank blue black block blow',
'blend_cl':'clump clap clip clock cloud clean',
'blend_fl':'flat flap float flop flip flower flight',
'blend_br':'brick bring broom brown brush bread brave brain',
'blend_tr':'track trap trick train tree truck trip trail',
'blend_st':'stand start stop stick star stay stain stamp',
'blend_sm':'smart smash smile smell small smoke',
'blend_sp':'spell spit spun sport spot spoon spider spin',
'blend_dr':'draw drink dream drain drop dress drum',
'blend_gl':'glad glow glass glove glue',
'blend_pl':'plan plug plain plop play plant',
'blend_sl':'slap slow sleep slide slope slug',
'blend_cr':'crack crop crank crash crown cry crab',
'blend_fr':'free frog fruit frame',
'blend_gr':'grin grand green grass grapes grow ground',
'blend_pr':'press prop prize print',
'blend_sc':'scan score scarf scooter scold',
'blend_sk':'skin skirt skip skate',
'blend_sn':'snug snail snake snow snap',
'blend_sw':'switch sweat swim sweet swing',
'blend_tw':'twig twin twist twelve',
'blend_spr':'spread spring spray sprout',
'blend_str':'strap strong street stripe string',
'blend_scr':'scrap scrub scratch scream',
'blend_sp extended':'spot sport spun spell',
'blend_br extended':'brain brick bring brave',
'blend_bl extended':'blink blank',
'advanced_-all':'fall call hall mall stall crawl',
'advanced_-old':'hold told sold bold mold',
'advanced_ear(near)':'clear dear fear year gear cheer beard',
'advanced_-ight':'tight sight fight might flight',
'advanced_-ind':'bind grind behind',
'advanced_-ost':'coast ghost host roast',
'advanced_-alk':'stalk sidewalk',
'advanced_soft c':'face place space ice nice rice mice pencil',
'advanced_soft g':'huge gentle giant gem orange',
'advanced_two-syllable words':'kitten napkin muffin button rocket panda pumpkin sunset bathtub football',
'advanced_unstressed schwa':'around above again away animal lemon',
'advanced_silent kn':'knit know knob knight',
'advanced_silent wr':'wrong wrinkle wreath',
'advanced_-tion':'addition vacation motion nation lotion',
'advanced_-le ending':'little bottle bubble middle puzzle',
'advanced_-ture ending':'future creature furniture capture',
}
# Some words in supplementary categories already exist in previous bank.
# Definitions for newly listed words are *required* (no speculative default).
fam_by_id={x['id']:x for x in data['families']}
fam_by_key={x['category']+'_'+x['pattern']:x for x in data['families']}
for id,x in fam_by_id.items():fam_by_key.setdefault(id,x)
missing_families=[k for k in GROUPS if k not in fam_by_key]
assert not missing_families,missing_families
word_to_group=collections.defaultdict(set)
for family_id,line in GROUPS.items():
 family=fam_by_key[family_id]
 for w in line.split():
  if w not in data['words'] and w not in new_data: raise AssertionError(f'Missing curated definition for {w} in {family_id}')
  if w not in family['words']:family['words'].append(w)
  word_to_group[w].add(family_id)
# Add only reviewed entries actually used by at least one lesson.
unused=sorted(set(new_data)-set(word_to_group))
if unused: print('Unused reviewed entries:',','.join(unused))
for w,group_ids in word_to_group.items():
 if w not in data['words']:
  item=new_data[w]
  item['categories']=sorted({fam_by_key[id]['category'] for id in group_ids})
  item['patterns']=sorted({fam_by_key[id]['pattern'] for id in group_ids})
  # For uncomplicated CVC items only, use letter-to-phoneme slots.
  # Others use an empty sound list rather than teaching an incorrect phoneme count.
  if re.fullmatch(r'[bcdfghjklmnpqrstvwxyz][aeiou][bcdfghjklmnpqrstvwxyz]',w) and w not in ('was','one','two','you','who','are','put','son','won','war'):
   item['sounds']=list(w)
  data['words'][w]=item
 else:
  item=data['words'][w]
  for id in group_ids:
   f=fam_by_key[id]
   if f['category'] not in item['categories']:item['categories'].append(f['category'])
   if f['pattern'] not in item['patterns']:item['patterns'].append(f['pattern'])
# Reorder group words by child-friendly priority: original cards first, then additions.
for f in data['families']:
 f['words']=list(dict.fromkeys(f['words']))
 if f['status']=='ready' and len(f['words'])>=2:
  f['teachingNote']=f.get('teachingNote') or ''
# Preserve 175 ready groups, seven planned: not every rare pattern has a large preschool vocabulary.
data['version']='4.4'
data['stage']='extended high-frequency phonics lessons'
data.setdefault('metadata',{})['expansion']='hand-reviewed lessons; 7 categories; common vocabulary and helpful extension words'
data['metadata']['wordCount']=len(data['words'])
data['metadata']['readyPatternCount']=len([f for f in data['families'] if f['status']=='ready'])
BANK.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('New words:',len(set(data['words'])-set(json.loads((ROOT/'wordbank_v43_backup.json').read_text(encoding='utf-8'))['words'])) if (ROOT/'wordbank_v43_backup.json').exists() else 'n/a')
print('Words:',len(data['words']),'families:',len(data['families']),'ar:',fam_by_id['r_ar']['words'])
