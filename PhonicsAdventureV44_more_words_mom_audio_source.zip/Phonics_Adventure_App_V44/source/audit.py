# -*- coding:utf-8 -*-
import json,re
from collections import Counter
from pathlib import Path
root=Path(__file__).parent
bank=json.loads((root/'wordbank.json').read_text(encoding='utf-8'))
words=bank['words'];fam=bank['families'];ready=[f for f in fam if f['status']=='ready'];planned=[f for f in fam if f['status']=='planned']
assert len(words)==887 and len(ready)==175 and len(planned)==7
assert len({f['id'] for f in fam})==len(fam)
assert len({w['id'] for w in words.values()})==len(words)
for f in ready:
 assert f['category'] in {c['id'] for c in bank['categories']}
 assert len(f['words'])>=2
 assert len(set(f['words']))==len(f['words'])
 assert all(w in words for w in f['words'])
for w,data in words.items():
 assert data['word']==w and w==w.lower() and w.isalpha()
 assert data['definition'] and data['sentence'] and data['emoji']
 assert any(f['status']=='ready' and w in f['words'] for f in fam)
 assert len(data['definition'])<125 and len(data['sentence'])<125
 assert data['sounds']==[] or all(isinstance(c,str) and c for c in data['sounds'])
for w in ['dip','sip','zip','lip','tip','rip','chip','ship','trip','flip','clip','hip']:
 assert (root/'assets'/f'{w}.webp').is_file()
print('PASS',len(words),'words',len(ready),'ready groups',len(planned),'planned groups')
print('groups by category',Counter(f['category'] for f in ready))
print('individual marked phoneme words:',sum(bool(w['sounds']) for w in words.values()))
