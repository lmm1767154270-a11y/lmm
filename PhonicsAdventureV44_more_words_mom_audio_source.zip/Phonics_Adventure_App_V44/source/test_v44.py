"""Local browser game QA. APK/Android media remain separately tested on user device."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent.parent
HTML=ROOT/'Phonics_Adventure_V4_离线试玩.html'
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(HTML.read_text(encoding='utf-8'),wait_until='load')
 assert '887' in page.locator('.hero-badges').inner_text()
 assert '175' in page.locator('.hero-badges').inner_text()
 page.locator('button[data-mode="word"]').click()
 page.locator('button[data-cat="r"]').click()
 assert page.locator('button[data-family="r_ar"]').count()==1
 assert '27 words' in page.locator('button[data-family="r_ar"]').inner_text()
 page.locator('button[data-family="r_ar"]').click()
 assert page.locator('.family-audio-word').count()==27
 assert page.locator('.family-audio-word [data-sayword]').count()==27
 # First card on ar; mom script immediately above card & visible (no disclosure clicks).
 page.locator('button[data-activity="cards"]').click()
 assert page.locator('.mom-inline').count()==1
 assert page.locator('details.mom').count()==0
 assert page.locator('.mom-inline').is_visible()
 assert page.locator('.mom-inline').evaluate('(e) => e.compareDocumentPosition(document.querySelector("#flip")) & Node.DOCUMENT_POSITION_FOLLOWING')>0
 assert page.locator('button.word-listen').count()>=27
 page.screenshot(path='/mnt/data/Phonics_Adventure_V44_翻卡与妈妈脚本.png',full_page=True)
 page.locator('[data-go="hub"]').click()
 for mode in ['picture','pattern','spell','sentence','build']:
  page.locator(f'button[data-activity="{mode}"]').click()
  assert page.locator('.mom-inline').count()==1,(mode,'mom missing')
  assert page.locator('details.mom').count()==0
  assert page.locator('.mom-inline').evaluate('(e) => e.compareDocumentPosition(document.querySelector(".answers, .spellslots, .sentence-answer")) & Node.DOCUMENT_POSITION_FOLLOWING')>0,(mode,'mom below question')
  count=page.locator('button[data-sayword]').count()
  assert count>=1,(mode,count)
  if mode in ('picture','pattern','sentence'):
   ans=page.locator('button[data-answer]').count()
   page.locator('.answer-option button[data-sayword]').first.click()
   assert page.locator('button[data-answer]').count()==ans
   assert page.locator('button[data-next]').count()==0,(mode,'listen unexpectedly answers')
  if mode=='build':
   first=page.locator('button[data-token]').first
   first.click()
   assert page.locator('button[data-unpick]').count()==1
  if mode=='sentence':
   assert page.locator('[data-saytext]').count()>=4
  if mode=='picture':
   page.screenshot(path='/mnt/data/Phonics_Adventure_V44_配对与妈妈脚本.png',full_page=True)
  if mode=='build':
   page.screenshot(path='/mnt/data/Phonics_Adventure_V44_造句与妈妈脚本.png',full_page=True)
  page.locator('button[data-go="hub"]').click()
 assert not errors,errors
 b.close()
print('PASS: word counts, AR group 27, audio on all games, mom scripts visible near questions, no accidental answers, browser JS errors=0')
