"""Compatibility test entrypoint for V4.4."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name('test_v44.py')),run_name='__main__')
