from pathlib import Path
import json,re,csv
p=Path(__file__).parent
j=json.loads((p/'wordbank.json').read_text(encoding='utf-8'))
words=j['words'];fs=j['families'];ready=[f for f in fs if f['status']=='ready'];planned=[f for f in fs if f['status']=='planned']
assert len(words)==525,(len(words),'Unexpected word count')
assert len(ready)==175,(len(ready),'Unexpected ready groups')
assert len({f['id'] for f in fs})==len(fs)
assert len({(f['category'],f['pattern']) for f in fs})==len(fs)
for f in ready:
 assert len(f['words'])>=2,(f['id'],f['words'])
 assert len(set(f['words']))==len(f['words']),(f['id'],'dup')
 for w in f['words']:assert w in words,(f['id'],w)
for name,w in words.items():
 assert name==w['id']==w['word']
 assert name.isalpha() and name.isascii() and name.islower()
 assert isinstance(w['definition'],str) and len(w['definition'])>=8
 assert isinstance(w['sentence'],str) and len(w['sentence'])>8
 assert w['emoji']
 assert any(name in f['words'] and f['status']=='ready' for f in fs)
 assert isinstance(w.get('sounds',[]),list)
print('PASS',len(words),'unique words,',len(ready),'playable groups,',len(planned),'planned groups')
