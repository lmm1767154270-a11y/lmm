"""Patch V3 application with STRICT human recording mode; no TTS fallback."""
from pathlib import Path
import re
p=Path(__file__).parent/'app.js'
s=p.read_text(encoding='utf-8')
# Remove speech engine, allow only loaded recordings. Never synthesize human speech.
start=s.index('// SpeechSynthesis is a DEVICE SYNTHESIZER;')
end=s.index('function avatar(',start)
new='''// HUMAN RECORDINGS ONLY. No speechSynthesis or AI voice is used anywhere in V4.
// Recorded voice clips can be bundled from licensed files or imported by parents.
const audioClips={}; let currentClip=null;
function hasHuman(key){return Boolean(audioClips[key] || (ASSETS.humanAudio && ASSETS.humanAudio[key]));}
function playHuman(key,quiet=false){
 const url=audioClips[key] || (ASSETS.humanAudio && ASSETS.humanAudio[key]);
 if(!url){if(!quiet)showToast('这段真人录音尚未添加，可在设置里批量导入');return false;}
 try{if(currentClip)currentClip.pause();currentClip=new Audio(url);currentClip.play().catch(()=>showToast('真人录音播放失败'));return true;}
 catch(e){if(!quiet)showToast('无法播放这段真人录音');return false;}
}
// Legacy audio function calls are supported without synthesizer fallback.
function synth(){/* intentional silence: no synthetic audio allowed */}
function playAudioText(text,key=null){return key ? playHuman(key) : playHuman('text:'+String(text).toLowerCase().replace(/[^a-z0-9]+/g,'_'));}
function sayPraise(){const n=1+Math.floor(Math.random()*8);if(!playHuman('praise:'+n,true))playHuman('praise',true);}
function sayWord(w){if(word(w))playHuman('word:'+w)}
function sayMeaning(w){if(word(w))playHuman('definition:'+w)}
'''
s=s[:start]+new+s[end:]
s=s.replace("const prefs=Object.assign({speech:true,rate:0.91,voice:''},storageGet('phonics.prefs.v3',{}));","const prefs={humanOnly:true};")
s=s.replace("${badge('🔊 系统英语朗读')}","${badge('🎙️ 仅真人录音（需导入）')}")
s=s.replace('音频为手机系统合成美式英语语音（非真人）；导入个人拥有使用权的真人音频后，该单词会优先播放真人录音。','只播放真人录音，没有录音时保持安静。可在本页或设置中导入本人录制或获授权的音频。')
s=s.replace('🎧 Sound Detective</b><small>听单词、数音素（需已标注音素）', '🎧 Sound Detective</b><small>听真人录音、数音素（需录音及音素标注）')
s=s.replace("${!f.words.some(w=>word(w).sounds.length>0)?'disabled':''}","${!f.words.some(w=>word(w).sounds.length>0 && hasHuman('word:'+w))?'disabled':''}")
s=s.replace("if(!array.length)return[];", "if(game==='sound')array=array.filter(w=>hasHuman('word:'+w));if(!array.length)return[];")
s=s.replace("${badge('⭐ 每题答对均有鼓励')}","${badge('⭐ 答对得星星；真人录音齐全后有语音鼓励')}")
# Replace settings panel functionality
s=re.sub(r'function voiceSelect\(\)\{.*?\}\nfunction renderSettings\(\)\{.*?\}\nfunction renderSearchResults', '''function renderSettings(){
 const wordReady=Object.keys(words).filter(w=>hasHuman('word:'+w)).length;
 const praiseReady=Array.from({length:8},(_,i)=>hasHuman('praise:'+(i+1))).filter(Boolean).length;
 view.innerHTML=`<section class="panel">${getPanel('🎙️ 真人配音素材库','PARENT SETTINGS','home')}
 ${mentor('alpha','Let’s listen and learn!')}
 <div class="statsline">${badge('单词真人录音 '+wordReady+' / '+Object.keys(words).length)}${badge('鼓励语录音 '+praiseReady+' / 8')}</div>
 <p class="settingnote"><b>重要：此版本严格禁用系统合成朗读和 AI 配音。</b> 当前安装包没有预装真人录音，导入之前是静音状态；不会把机械朗读伪装成真人发音。词卡、游戏、星星奖励仍然能正常使用。</p>
 <div class="audio-panel"><strong>📁 批量导入真人录音</strong>
 <p class="settingnote">可以一次选取多段 MP3、M4A、WAV、OGG 音频。命名规则：<code>word_cat.mp3</code>、<code>definition_cat.mp3</code>、<code>sentence_cat.mp3</code>、<code>praise_1.mp3</code> … <code>praise_8.mp3</code>。所有音频应为你录制或已有明确许可的真人声音。</p>
 <label class="filebox">📥 选择多个真人音频文件<input type="file" id="bulkAudioImport" accept="audio/*" multiple /></label>
 <p class="settingnote">导入后保存在此应用自己的本地储存区。无需上传服务器。建议在安卓 App 中使用以避免普通浏览器的文件储存限制。</p></div>
 <div class="mini-row"><button class="flatbtn blue" id="testVoice">▶️ Test human praise #1</button><button class="flatbtn" data-go="home">返回首页</button></div>
 </section>`;
}
function renderSearchResults''',s,count=1,flags=re.S)
s=s.replace("if(b.id==='testVoice')return synth('Great job! You are a word star!');","if(b.id==='testVoice')return playHuman('praise:1');")
start=s.index("view.addEventListener('input',e=>{")
end=s.index('// Pointer drag:',start)
s=s[:start]+'''view.addEventListener('input',e=>{if(e.target.id==='wordSearch')renderSearchResults(e.target.value)});
view.addEventListener('change',async e=>{
 if(e.target.dataset.importword){const file=e.target.files?.[0];if(file)await importRecordedAudio('word:'+e.target.dataset.importword,file)}
 if(e.target.id==='bulkAudioImport'){
  const files=Array.from(e.target.files||[]);let good=0;for(const file of files){
   const m=/^(word|definition|sentence|praise)[_-]([a-z0-9]+)\\.(mp3|wav|ogg|m4a|aac)$/i.exec(file.name);
   if(!m)continue;
   const key=m[1].toLowerCase()+':'+m[2].toLowerCase();
   if(key.startsWith('word:')&&!words[key.slice(5)])continue;
   await importRecordedAudio(key,file,true); good++;
  }
  showToast('成功导入 '+good+' / '+files.length+' 段真人录音');render();
 }
});
''' +s[end:]
s=s.replace('async function importRecordedAudio(key,file){', 'async function importRecordedAudio(key,file,quiet=false){')
s=s.replace("showToast('已保存真人音频到本机浏览器')", "!quiet&&showToast('真人录音已保存到本机')")
s=s.replace("showToast('已加入本次游戏；浏览器不支持长期保存')", "!quiet&&showToast('已加入本次游戏；可能不能长期保存')")
s=s.replace("showToast('已加入本次游戏，重新打开可能需要再导入')", "!quiet&&showToast('已导入，重启可能需再导入')")
s=s.replace("if('speechSynthesis' in window){window.speechSynthesis.onvoiceschanged=()=>{if(ST.page==='settings')renderSettings()}}",'')
p.write_text(s,encoding='utf-8')
print('patched',len(s),'speechSynthesis' in s)
