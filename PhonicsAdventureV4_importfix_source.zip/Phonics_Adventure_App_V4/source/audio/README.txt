PLACEHOLDER - NO third-party voice recordings are bundled.
For word pronunciation and celebratory lines, the app uses Web Speech API device TTS unless a user imports a permitted human recording.
Only add human recordings if you hold rights or have permission to use them. Maintain author, source URL, license, accent, version, and word mapping metadata.
