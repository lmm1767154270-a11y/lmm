"""Headless touchscreen smoke tests. Does not test Android APK install."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent
html=root/'Phonics_Adventure_V4_离线试玩.html'
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html.read_text('utf-8'),wait_until='load')
 assert page.locator('.module').count()==3
 assert '525' in page.locator('.hero-badges').inner_text()
 assert '175' in page.locator('.hero-badges').inner_text()
 page.locator('button[data-family="short_-ip"]').click()
 assert page.locator('.activity').count()==7
 page.locator('button[data-activity="cards"]').click()
 page.locator('#flip').click()
 assert 'flipped' in page.locator('#flip').get_attribute('class')
 assert 'Put something into a liquid' in page.content()
 page.locator('button[data-go="hub"]').click()
 page.locator('button[data-activity="spell"]').click()
 target=page.locator('[data-sayword]').first.get_attribute('data-sayword')
 for letter in target:
  tiles=page.locator('button.tile:not(.used)')
  idx=next(el.get_attribute('data-tile') for el in tiles.all() if el.inner_text().strip()==letter)
  page.locator('button[data-tile="'+idx+'"]').click()
 assert page.locator('button[data-next]').count()==1
 page.locator('button[data-go="hub"]').click()
 page.locator('button[data-go="home"]').first.click()
 page.locator('button[data-go="settings"]').click()
 assert page.locator('#bulkAudioImport').count()==1
 assert page.locator('#speechToggle').count()==0
 assert page.locator('#voiceSelect').count()==0
 assert not errors, errors
 browser.close()
print('PASS mobile touch, flip-card, spelling, rewards, strict-human-audio settings, JS errors=0')
