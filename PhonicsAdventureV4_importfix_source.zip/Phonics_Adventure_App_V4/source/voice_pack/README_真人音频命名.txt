请将授权真人发音录音放在这个文件夹，文件名要求：
word_cat.mp3  — 真人朗读单词 cat
definition_cat.mp3 — 真人朗读卡片背面的英文解释
sentence_cat.mp3 — 真人朗读cat对应的完整示例句子
praise_1.mp3...praise_8.mp3 — 真人鼓励语
可用mp3、m4a、wav、ogg、aac音频格式。请确认美式英语口音、清晰度、许可。
注意：这个文件夹目前没有音频。软件不会自动产生真人语音。
