#!/usr/bin/env python3
"""Offline audit for genuine, separately sourced human speech assets."""
from pathlib import Path
import json,csv,sys
D=Path(__file__).resolve().parent
words=json.loads((D/'wordbank.json').read_text(encoding='utf-8'))['words']
files={f.stem.lower():f for f in (D/'voice_pack').glob('*') if f.suffix.lower() in ('.mp3','.m4a','.wav','.ogg','.aac')}
checks=[('word',w) for w in words]+[('definition',w) for w in words]+[('sentence',w) for w in words]+[('praise',str(i)) for i in range(1,9)]
missing=[(kind,w) for kind,w in checks if kind+'_'+w not in files]
print('WORDS',len(words),'AUDIO FILES',len(files),'REQUIRED',len(checks),'MISSING',len(missing))
for kind in ('word','definition','sentence','praise'):
 target=[(k,w) for k,w in checks if k==kind]
 ready=sum(k+'_'+w in files for k,w in target)
 print(f'{kind:11} {ready:4} / {len(target):4}')
out=D/'audio_missing_report.csv'
with out.open('w',encoding='utf-8-sig',newline='') as f:
 wr=csv.writer(f);wr.writerow(['type','target','expected_filename','status'])
 for kind,w in checks:wr.writerow([kind,w,kind+'_'+w+'.mp3','missing' if (kind,w) in missing else 'present'])
print('REPORT',out)
if '--require-complete' in sys.argv and missing:sys.exit(2)
