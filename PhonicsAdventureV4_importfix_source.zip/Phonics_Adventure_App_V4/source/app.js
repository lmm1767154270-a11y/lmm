(() => {
'use strict';
const $=(s)=>document.querySelector(s);
const view=$('#view');
const words=BANK.words;
const ready=BANK.families.filter(f=>f.status==='ready');
const planned=BANK.families.filter(f=>f.status==='planned');
const cat=(id)=>BANK.categories.find(c=>c.id===id)||BANK.categories[0];
const fam=(id)=>ready.find(f=>f.id===id)||ready[0];
const word=(id)=>words[id];
const esc=(s)=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const rand=(a)=>a[Math.floor(Math.random()*a.length)];
const shuffle=(a)=>{let b=[...a];for(let i=b.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]]}return b};
const sample=(a,n)=>shuffle(a).slice(0,n);
const unique=(a)=>[...new Set(a)];
function storageGet(k,def){try{const v=localStorage.getItem(k);return v===null?def:JSON.parse(v)}catch(e){return def}}
function storageSet(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
const progress=storageGet('phonics.progress.v3',{awards:{}, total:0});
const prefs={humanOnly:true};
const ST={page:'home',mode:'word',category:'short',family:ready[0].id,wordIndex:0,flipped:false,game:'',taskIndex:0,tasks:[],answered:false,chosen:null,spellSlots:[],spellTiles:[],usedTiles:[],builderTokens:[],builderPicked:[],notice:'',feedback:''};
// Three-stage sentence ladders are hand-curated, not auto-invented from grammar.
const LADDERS={
 dip:'dip the cookie',sip:'a little sip',zip:'zip up',lip:'my lip',tip:'the pencil tip',rip:'rip the paper',
 chip:'a potato chip',ship:'a big ship',trip:'do not trip',flip:'flip it over',clip:'a hair clip',hip:'my hip',
 cat:'a little cat',bat:'a flying bat',hat:'my red hat',mat:'on the mat',rat:'a little rat',sat:'sat on a chair',
 man:'the man',pan:'the pan',fan:'the fan',can:'a can',van:'the van',ran:'ran fast',
 pig:'a pink pig',wig:'a funny wig',dig:'dig a hole',big:'a big elephant',
 sun:'the warm sun',run:'run fast',fun:'lots of fun',bun:'a little bun',
 bed:'my bed',red:'a red apple',pen:'a blue pen',hen:'a hen',dog:'a dog',log:'a heavy log',
 boat:'a little boat',rain:'the rain',tree:'a tall tree',bee:'a little bee',
 cake:'a sweet cake',bike:'my bike',moon:'the moon',book:'a big book',
 whale:'a big whale',train:'a fast train',goat:'a little goat',sock:'my sock',duck:'a yellow duck'
};
function ladder(w){const item=word(w);if(!item)return '';const phrase=LADDERS[w];return `<div class="reveal"><strong>🌱 Grow a sentence · 逐步扩句</strong><div class="statsline" style="justify-content:center;margin:10px 0"><span class="stat">1 · ${esc(item.word)}</span>${phrase?`<span class="stat">2 · ${esc(phrase)}</span>`:''}</div><p>3 · ${esc(item.sentence)}</p><button class="audio guide" data-saytext="${esc(item.sentence)}">🔊 Listen & say</button></div>`}
const mentors={word:{img:'ruby',name:'Ruby · 词族小队长',tone:'pink',line:'Let’s find words that belong together!'},alpha:{img:'pip',name:'Pip · 字母小侦探',tone:'pig',line:'Look, listen, and build the word!'},sentence:{img:'nova',name:'Nova · 句子小英雄',tone:'boy',line:'Let’s make a big sentence!'}};
let toastHandle=null;
function showToast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toastHandle);toastHandle=setTimeout(()=>el.classList.remove('show'),2200)}
function stars(){return Number(progress.total)||0}
function saveProgress(){storageSet('phonics.progress.v3',progress);const s=$('#stars');if(s)s.textContent=stars()}
function reward(key,said){if(!progress.awards[key]){progress.awards[key]=1;progress.total=stars()+1;saveProgress()};burst();sayPraise(said)}
function burst(){const e=$('#confetti');e.innerHTML='';let c=['#ffb940','#fa5b8a','#79cf8b','#69b6ee','#a98efa','#f79a51'];for(let i=0;i<19;i++){const z=document.createElement('i');z.style.left=(5+Math.random()*90)+'%';z.style.background=rand(c);z.style.animationDelay=(Math.random()*.18)+'s';z.style.transform=`rotate(${Math.random()*360}deg)`;e.appendChild(z)}setTimeout(()=>e.innerHTML='',1800)}
// HUMAN RECORDINGS ONLY. No speechSynthesis or AI voice is used anywhere in V4.
// Recorded voice clips can be bundled from licensed files or imported by parents.
const audioClips={}; let currentClip=null;
function hasHuman(key){return Boolean(audioClips[key] || (ASSETS.humanAudio && ASSETS.humanAudio[key]));}
function playHuman(key,quiet=false){
 const url=audioClips[key] || (ASSETS.humanAudio && ASSETS.humanAudio[key]);
 if(!url){if(!quiet)showToast('尚无真人录音。可在单词卡下面点击“导入真人发音”');return false;}
 try{if(currentClip)currentClip.pause();currentClip=new Audio(url);currentClip.play().catch(()=>showToast('真人录音播放失败'));return true;}
 catch(e){if(!quiet)showToast('无法播放这段真人录音');return false;}
}
// Legacy audio function calls are supported without synthesizer fallback.
function synth(){/* intentional silence: no synthetic audio allowed */}
// Resolve the sentence/definition recorded under the corresponding word ID.
// V4 mistakenly requested text:<slug>, while its recording guide used sentence_<word>.
const audioTextKey={};
function normalizeAudioText(t){return String(t||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();}
for(const w of Object.keys(words)){
 const info=words[w];
 if(info.sentence)audioTextKey[normalizeAudioText(info.sentence)]='sentence:'+w;
 if(info.definition)audioTextKey[normalizeAudioText(info.definition)]='definition:'+w;
}
function playAudioText(text,key=null){
 const resolved=key || audioTextKey[normalizeAudioText(text)] || 'text:'+String(text).toLowerCase().replace(/[^a-z0-9]+/g,'_');
 return playHuman(resolved);
}
// Choose only among recordings actually available, avoiding 7/8 silent praise clicks.
function sayPraise(){
 const available=Array.from({length:8},(_,i)=>'praise:'+(i+1)).filter(hasHuman);
 if(!available.length && hasHuman('praise'))available.push('praise');
 if(available.length)playHuman(available[Math.floor(Math.random()*available.length)],true);
 // Visual celebration remains even when no human voice has been added.
}
function sayWord(w){if(word(w))playHuman('word:'+w)}
function sayMeaning(w){if(word(w))playHuman('definition:'+w)}
function avatar(which,cls=''){return `<img class="${cls}" src="${ASSETS.avatars[which]}" alt="原创卡通角色 ${which==='ruby'?'Ruby红粉色短发女孩':which==='pip'?'Pip戴绿色眼镜小猪':'Nova蓝披风男孩'}">`}
function picture(w,size=''){const item=typeof w==='string'?word(w):w;if(!item)return '';return `<div class="picture ${size}">${ASSETS.words[item.word]?`<img loading="lazy" src="${ASSETS.words[item.word]}" alt="${esc(item.word)} 的插画：${esc(item.definition)}">`:`<span class="emoji" role="img" aria-label="${esc(item.word)} 的图像标记">${esc(item.emoji)}</span>`}</div>`}
function badge(txt){return `<span class="stat">${txt}</span>`}
function familyWords(f=curFamily()){return f.words.map(w=>word(w)).filter(Boolean)}
function curFamily(){return fam(ST.family)}
function getPanel(title,kicker='',back='hub'){return `<div class="panel-head"><div><div class="eyebrow">${esc(kicker)}</div><h2>${title}</h2></div><button class="back" data-go="${esc(back)}">‹ 返回</button></div>`}
function mentor(mode='word',message=''){let m=mentors[mode];return `<div class="mentor ${m.tone}">${avatar(m.img)}<p><strong>${esc(m.name)}</strong>“${esc(message||m.line)}”</p></div>`}
function go(page){ST.page=page;ST.feedback='';render();window.scrollTo({top:0,behavior:'instant'})}
function toLibrary(mode='word'){ST.mode=mode;go('library')}
function selectFamily(id){const f=ready.find(x=>x.id===id);if(!f){showToast('这组词还在整理中');return}ST.family=f.id;ST.wordIndex=0;ST.flipped=false;go('hub')}
function actionTiles(mode='word'){return `<div class="module-grid"><button class="module word" data-mode="word">${avatar('ruby')}<b>Word Family<br>Rescue</b><small>词族救援 · 翻卡</small><span class="pill">★ Ruby</span></button><button class="module alpha" data-mode="alpha">${avatar('pip')}<b>Alphabet<br>Adventure</b><small>字母拼写 · 辨音</small><span class="pill">★ Pip</span></button><button class="module sentence" data-mode="sentence">${avatar('nova')}<b>Sentence<br>Power</b><small>理解 · 造句</small><span class="pill">★ Nova</span></button></div>`}
function renderHome(){const n=Object.keys(words).length;const r=ready.length;view.innerHTML=`<section class="hero"><h1>Phonics<br>Adventure!</h1><p class="eng">Read · Spell · Say · Play!</p><p class="cn">和三个原创小伙伴一起寻找词族、拼写单词、说出完整句子！</p><div class="hero-avatars">${avatar('ruby')}${avatar('pip')}${avatar('nova')}</div><div class="hero-badges"><span>✨ ${n} 个单词</span><span>🃏 ${r} 个可玩分组</span><span>🏆 做对就奖励</span></div></section>${actionTiles()}<div class="quick-title">🚀 今天先玩一组</div><div class="quick-grid">${['-ip','-at','-ock','ai'].map(p=>{let f=ready.find(x=>x.pattern===p);return `<button class="quick" data-family="${esc(f.id)}"><strong>${esc(p)}</strong><small>${f.words.length} words</small></button>`}).join('')}</div><section class="panel"><h2>👩 给妈妈的小提示</h2><p class="lead">先翻卡认意思，再找同韵词，接着用字母拼出单词，最后用完整句说出来。每次学一组就好。</p><div class="statsline">${badge('📱 安卓 / iPad 触屏')}${badge('🎙️ 仅真人录音（需导入）')}${badge('🧩 支持离线单文件')}${badge('📖 可扩充 JSON 词库')}</div><p class="footnote">本版只有 -ip 的12张是绘制插画；其他词卡使用对应图像标记，后续可逐批升级为原创插画。</p></section>`}
function renderLibrary(){const c=cat(ST.category);const active=ready.filter(f=>f.category===c.id),upcoming=planned.filter(f=>f.category===c.id);view.innerHTML=`<section class="panel">${getPanel('选一个拼读规律','SELECT A PHONICS PATTERN','home')}${mentor(ST.mode, ST.mode==='alpha'?'Pick a pattern, and let’s build some words!':ST.mode==='sentence'?'Pick a word family to make sentences!':'Pick a word family and discover new words!')}<div class="tabs">${BANK.categories.map(x=>`<button class="tab ${x.id===c.id?'active':''}" data-cat="${esc(x.id)}">${x.icon} ${esc(x.name.split(' · ')[0])}</button>`).join('')}</div><p class="muted">${esc(c.hint)}</p><div class="statsline">${badge('可玩 '+active.length+' 组')}${badge('词卡 '+unique(active.flatMap(f=>f.words)).length+' 张')}${badge('待扩充 '+upcoming.length+' 组')}</div><div class="familygrid">${active.map(f=>`<button class="familybtn" data-family="${esc(f.id)}"><b>${esc(f.label)}</b><span>📚 ${f.words.length} words · 开始 ›</span></button>`).join('')}</div>${upcoming.length?`<details class="planned"><summary>🗂️ 待扩充规律（${upcoming.length} 组）· 点击查看</summary><div class="planned-tags">${upcoming.map(f=>`<span>${esc(f.label)}</span>`).join('')}</div></details>`:''}</section><section class="panel"><h2>🔎 按单词查找</h2><input type="search" id="wordSearch" class="search" placeholder="输入单词，例如 cat、moon、ship" autocomplete="off" aria-label="搜索英语单词"/><div id="searchResult" class="search-results"></div></section>`}
function renderHub(){const f=curFamily(),c=cat(f.category);const isRhyme=f.category==='short'&&f.pattern.startsWith('-');view.innerHTML=`<section class="panel">${getPanel('📚 '+esc(f.label)+' Word Adventure','CHOOSE A GAME','library')}<p class="muted">${esc(c.name)} · 本组 ${f.words.length} 个单词。选一关开始吧！</p>${mentor(ST.mode,ST.mode==='sentence'?'Look at the picture. Let’s talk about it!':ST.mode==='alpha'?'Ready to mix letters into a word?':'Flip, discover, and rescue the words!')}<div class="activity-grid"><button class="activity" data-activity="cards"><span class="ico">🃏</span><b>Flip & Discover</b><small>翻卡：单词 → 图片 + 英文解释</small></button><button class="activity" data-activity="picture"><span class="ico">🖼️</span><b>Picture Match</b><small>看单词，选对的图片</small></button><button class="activity" data-activity="${isRhyme?'rhyme':'pattern'}"><span class="ico">🎶</span><b>${isRhyme?'Rhyme Rescue':'Find the Pattern'}</b><small>${isRhyme?'寻找押韵词，同韵词闯关':'辨认属于当前拼读规律的单词'}</small></button><button class="activity" data-activity="spell"><span class="ico">🔡</span><b>Spell It!</b><small>拖动或点击字母，拼出单词</small></button><button class="activity" data-activity="sound" ${!f.words.some(w=>word(w).sounds.length>0 && hasHuman('word:'+w))?'disabled':''}><span class="ico">🎧</span><b>Sound Detective</b><small>听单词、数音素（需已标注音素）</small></button><button class="activity" data-activity="sentence"><span class="ico">💬</span><b>Sentence Power</b><small>看图理解句子、完整句表达</small></button><button class="activity" data-activity="build"><span class="ico">🧱</span><b>Build a Sentence</b><small>把单词积木排成一句话</small></button></div><div class="statsline" style="margin-top:15px">${badge('⭐ 答对得星星；真人录音齐全后有语音鼓励')}${badge('👩 可展开妈妈照读脚本')}</div></section>`}
function cardContent(item,flip){return `<div class="flipwrap"><button class="flipcard ${flip?'flipped':''}" id="flip" aria-label="点击翻转 ${esc(item.word)} 单词卡，背面有图像与英文解释"><span class="face facefront"><small>MAGIC WORD CARD</small><span class="word">${esc(item.word)}</span><span class="hint">👆 Tap to flip · 点击翻面</span></span><span class="face faceback"><strong class="word">${esc(item.word)}</strong>${picture(item)}<span class="definition">${esc(item.definition)}</span><span class="hint">👆 Tap to turn back</span></span></button></div>`}
function renderCards(){const f=curFamily(),index=ST.wordIndex%f.words.length,item=word(f.words[index]);view.innerHTML=`<section class="panel">${getPanel('🃏 Flip & Discover','RUBY · WORD CARDS')}${mentor('word','Tap the word. Flip the card. What can you see?')}<div class="wordbar">${f.words.map((w,i)=>`<button class="wordchip ${i===index?'active':''}" data-index="${i}">${esc(w)}</button>`).join('')}</div>${cardContent(item,ST.flipped)}<div class="arrowrow"><button class="flatbtn" data-carddir="-1">‹ 上一张</button><span class="stat">${index+1} / ${f.words.length}</span><button class="flatbtn blue" data-carddir="1">下一张 ›</button></div><div class="audiorow"><button class="audio" data-sayword="${esc(item.word)}">🔊 Listen · 听单词</button><button class="audio guide" data-saymeaning="${esc(item.word)}">🎧 Explain · 听解释</button></div><div class="audiorow"><label class="filebox">➕ 为 ${esc(item.word)} 导入真人发音<input type="file" accept="audio/*,.ogg,.oga,.mp3,.wav,.m4a,.aac" data-importword="${esc(item.word)}" /></label></div><p class="footnote">只播放真人录音，没有录音时保持安静。可在本页或设置中导入本人录制或获授权的音频。</p><details class="mom"><summary>👩 Mom · 打开妈妈照读脚本</summary><p><b>Mom:</b> What word do you see? It says <b>${esc(item.word)}</b>. Can you say it?</p><p><b>Mom:</b> Let’s flip the card! What can you see?</p><p><b>Mom:</b> ${esc(item.definition)}</p><p><b>Mom:</b> Say this with me: <b>${esc(item.sentence)}</b></p><p><b>Child:</b> ${esc(item.sentence)}</p></details></section>`}
function progressUI(){return `<div class="progress"><span>${ST.taskIndex+1} / ${ST.tasks.length}</span><div class="track"><i style="width:${Math.round((ST.taskIndex+Number(ST.answered))/ST.tasks.length*100)}%"></i></div><span>⭐ ${stars()}</span></div>`}
function taskTitle(){return {rhyme:'🎵 Rhyme Rescue',pattern:'🔎 Find the Pattern',picture:'🖼️ Picture Match',spell:'🔡 Spell It!',sound:'🎧 Sound Detective',sentence:'💬 Sentence Power',build:'🧱 Build a Sentence'}[ST.game]||'Game'}
function taskMentor(){return {rhyme:'word',pattern:'word',picture:'word',spell:'alpha',sound:'alpha',sentence:'sentence',build:'sentence'}[ST.game]}
function taskIntro(){return {rhyme:'Which word rhymes with my word?',pattern:'Which word belongs to this phonics pattern?',picture:'Find the picture!',spell:'Look at the picture. Build the word!',sound:'Listen closely. How many sounds do you hear?',sentence:'Which sentence matches the picture?',build:'Put the word blocks in the right order!'}[ST.game]}
function candidates(target,f,count=3){const current=new Set(f.words);return sample(Object.keys(words).filter(w=>!current.has(w)&&w!==target&&words[w].emoji!==words[target].emoji),count)}
function makeTasks(game,f){let array=sample(f.words,Math.min(f.words.length,6));if(game==='sound')array=array.filter(w=>words[w].sounds.length>=2&&words[w].sounds.length<=5);if(game==='sound')array=array.filter(w=>hasHuman('word:'+w));if(!array.length)return[];
return array.map((id,i)=>{const w=word(id),other=candidates(id,f,3);if(game==='rhyme'){const cues=f.words.filter(x=>x!==id);return {id,cue:rand(cues),options:shuffle([id,...other])}}if(game==='pattern'){return{id,options:shuffle([id,...other])}}if(game==='picture'||game==='sentence'){return {id,options:shuffle([id,...other])}}if(game==='sound'){return{id,options:shuffle(unique([2,3,4,5,Math.min(5,w.sounds.length)]))}}if(game==='spell'){return {id,letters:shuffle(id.split(''))}}if(game==='build'){let tokens=(w.sentence.match(/[\w']+/g)||[]);return {id,tokens:shuffle(tokens),correct:tokens}}return{id}})}
function startGame(game){const f=curFamily();ST.game=game;ST.taskIndex=0;ST.tasks=makeTasks(game,f);if(!ST.tasks.length){showToast('这组暂时没有适合该玩法的题目');return}resetTask();go('game')}
function resetTask(){ST.answered=false;ST.chosen=null;ST.spellSlots=[];ST.usedTiles=[];ST.builderPicked=[];ST.feedback=''}
function taskNext(){if(ST.taskIndex+1>=ST.tasks.length){go('complete')}else{ST.taskIndex++;resetTask();render()}}
function renderGame(){const t=ST.tasks[ST.taskIndex],item=word(t.id),mentorMode=taskMentor();if(!t){go('complete');return}
let content='';
if(ST.game==='rhyme') content=`<div class="task">Which word rhymes with <em>${esc(t.cue)}</em>?</div><div class="audiorow"><button class="audio" data-sayword="${esc(t.cue)}">🔊 Listen to ${esc(t.cue)}</button></div><div class="answers">${t.options.map(id=>answerWord(id,t.id)).join('')}</div>`;
if(ST.game==='pattern') content=`<div class="task">Find a word from <em>${esc(curFamily().label)}</em>!</div><div class="answers">${t.options.map(id=>answerWord(id,t.id)).join('')}</div>`;
if(ST.game==='picture') content=`<div class="task">Find the picture for <em>${esc(t.id)}</em>!</div><div class="audiorow"><button class="audio" data-sayword="${esc(t.id)}">🔊 ${esc(t.id)}</button></div><div class="answers">${t.options.map(id=>`<button class="answer ${ST.answered&&id===t.id?'correct':''}" data-answer="${esc(id)}">${picture(id,'tiny')}<small>${ST.answered&&id===t.id?esc(id):'Tap the picture'}</small></button>`).join('')}</div>`;
if(ST.game==='sound')content=`${picture(item,'compact')}<div class="task">How many sounds in <em>${esc(t.id)}</em>?</div><div class="audiorow"><button class="audio" data-sayword="${esc(t.id)}">🔊 Listen again</button></div><div class="answers">${t.options.map(n=>`<button class="answer ${ST.answered&&n===item.sounds.length?'correct':''}" data-num="${n}">${n} sounds</button>`).join('')}</div>${ST.answered?`<div class="soundparts">${item.sounds.map(s=>`<span class="soundpart">${esc(s)}</span>`).join('')}</div>`:''}`;
if(ST.game==='spell'){
 const slots=ST.spellSlots.length?ST.spellSlots:Array.from({length:t.id.length},()=>null);content=`${picture(item,'compact')}<div class="task">Spell the word! <button class="audio" data-sayword="${esc(t.id)}">🔊 Listen</button></div><div class="spellslots" id="spellSlots">${slots.map((v,i)=>`<span class="slot ${v!==null?'filled':''}" data-slot="${i}">${v!==null?esc(t.letters[v]):'_'}</span>`).join('')}</div><div class="tiles">${t.letters.map((letter,i)=>`<button class="tile ${ST.usedTiles.includes(i)?'used':''}" data-tile="${i}" ${ST.usedTiles.includes(i)||ST.answered?'disabled':''} aria-label="字母 ${esc(letter)} 可点选或拖放">${esc(letter)}</button>`).join('')}</div>${!ST.answered?`<div class="mini-row"><button class="flatbtn" data-undo="spell">↶ Undo · 撤销</button><button class="flatbtn" data-reset="spell">↻ 重拼</button></div>`:''}<p class="footnote">点字母即可填入；也可以把字母拖到任意空格。不会因为不小心拼错而扣星星。</p>`;
}
if(ST.game==='sentence')content=`${picture(item,'compact')}<div class="task">Which sentence matches this picture?</div><div class="answers text-answers">${t.options.map(id=>`<button class="answer ${ST.answered&&id===t.id?'correct':''}" data-answer="${esc(id)}">${esc(word(id).sentence)}</button>`).join('')}</div>`;
if(ST.game==='build'){
 const tokens=t.correct;content=`${picture(item,'compact')}<div class="task">Build a sentence with <em>${esc(t.id)}</em>.</div><div class="sentence-answer" id="sentenceAnswer">${ST.builderPicked.length?ST.builderPicked.map((pos,i)=>`<button data-unpick="${i}">${esc(t.tokens[pos])}</button>`).join(''):`<small style="font-size:12px;color:#88a0bc">Tap the word blocks below!</small>`}</div><div class="sentence-tiles">${t.tokens.map((x,i)=>`<button data-token="${i}" ${ST.builderPicked.includes(i)||ST.answered?'disabled':''}>${esc(x)}</button>`).join('')}</div><div class="audiorow"><button class="audio" data-saytext="${esc(item.sentence)}">🔊 Listen to the sentence</button><button class="flatbtn" data-reset="build">↻ Reset</button></div>`;
}
const feedback=ST.feedback?`<div class="feedback ${ST.answered?'good':''}">${esc(ST.feedback)}</div>`:'<div class="feedback"></div>';
const revealed=ST.answered?`<div class="reveal"><strong>✨ ${ST.game==='build'?'Super sentence!':ST.game==='spell'?'You spelled it!':'You did it!'}</strong><p><b>${esc(t.id)}</b> · ${esc(item.definition)}</p>${ST.game==='rhyme'||ST.game==='picture'||ST.game==='pattern'?picture(item,'compact'):''}${(ST.game==='sentence'||ST.game==='build')?ladder(item.word):''}<div class="audiorow"><button class="audio" data-sayword="${esc(t.id)}">🔊 ${esc(t.id)}</button><button class="audio guide" data-saytext="${esc(item.sentence)}">💬 ${esc(item.sentence)}</button></div></div><button class="mainbtn green" data-next="1">${ST.taskIndex===ST.tasks.length-1?'Finish! 🏆':'Next challenge →'}</button>`:'';
view.innerHTML=`<section class="panel">${getPanel(taskTitle(),'LEVEL · '+(ST.taskIndex+1)+' / '+ST.tasks.length)}${mentor(mentorMode,taskIntro())}${progressUI()}${content}${feedback}${revealed}<details class="mom"><summary>👩 Mom · 本题照读引导（展开）</summary><p><b>Mom:</b> ${esc(taskIntro())}</p><p><b>Mom:</b> Look at the picture. Let’s think about the word.</p><p><b>Mom:</b> ${esc(item.definition)}</p><p><b>Mom:</b> Say it with me: ${esc(item.sentence)}</p><p><b>Child:</b> ${esc(item.sentence)}</p></details></section>`}
function answerWord(id,answer){return `<button class="answer ${ST.answered&&id===answer?'correct':''}" data-answer="${esc(id)}">${esc(id)}</button>`}
function checkAnswer(answer){if(ST.answered)return;const t=ST.tasks[ST.taskIndex];const good=ST.game==='sound'?Number(answer)===word(t.id).sounds.length:answer===t.id;if(good){ST.answered=true;ST.feedback=rand(['🌟 Great job!','🎉 You found it!','✨ Super work!','⭐ Fantastic!']);reward(`${curFamily().id}:${ST.game}:${t.id}`);render()}else{ST.feedback='Not quite. Try again!';showToast('Try again! You can do it.');synth('Try again!');render()}}
function fillTile(index,slotIndex=null){if(ST.answered)return;const t=ST.tasks[ST.taskIndex];if(ST.usedTiles.includes(index))return;if(!ST.spellSlots.length)ST.spellSlots=Array(t.id.length).fill(null);if(slotIndex===null||ST.spellSlots[slotIndex]!==null)slotIndex=ST.spellSlots.findIndex(x=>x===null);if(slotIndex<0)return;ST.spellSlots[slotIndex]=index;ST.usedTiles.push(index);if(ST.spellSlots.every(x=>x!==null)){
 const built=ST.spellSlots.map(i=>t.letters[i]).join('');if(built===t.id){ST.answered=true;ST.feedback='🌟 Wonderful! You spelled '+t.id+'!';reward(`${curFamily().id}:spell:${t.id}`)}else{ST.feedback='Try moving the letters. You can do it!';synth('Try again!')} }
render();}
function undoSpell(){if(ST.answered)return;const last=ST.usedTiles.pop();if(last!==undefined){const i=ST.spellSlots.indexOf(last);if(i>=0)ST.spellSlots[i]=null}ST.feedback='';render()}
function takeToken(index){if(ST.answered||ST.builderPicked.includes(index))return;const t=ST.tasks[ST.taskIndex];ST.builderPicked.push(index);if(ST.builderPicked.length===t.tokens.length){const built=ST.builderPicked.map(i=>t.tokens[i]);if(built.every((part,i)=>part.toLowerCase()===t.correct[i].toLowerCase())){ST.answered=true;ST.feedback='🎉 Great sentence! Say it out loud!';reward(`${curFamily().id}:build:${t.id}`)}else{ST.feedback='Almost! Tap a word to move it back.';synth('Try again!')}}render()}
function unpickToken(index){if(ST.answered)return;ST.builderPicked.splice(index,1);ST.feedback='';render()}
function renderComplete(){view.innerHTML=`<section class="panel complete"><div class="stars-big">🏆🌟🎉</div><h2>Hooray! You did it!</h2><p>You finished ${esc(taskTitle())} in ${esc(curFamily().label)}.<br>Come back to try another adventure!</p><div class="statsline" style="justify-content:center;margin:15px 0">${badge('⭐ '+stars()+' stars collected')}${badge('📚 '+Object.keys(progress.awards).length+' achievements')}</div><button class="mainbtn" data-go="hub">再选一种游戏 · More Games</button><button class="mainbtn blue" data-go="library">换一个词族 · New Family</button></section>`;}
function renderRewards(){const awards=Object.keys(progress.awards);view.innerHTML=`<section class="panel">${getPanel('🏆 My Star Collection','REWARD BOARD','home')}<div class="complete"><div class="stars-big">⭐ ${stars()}</div><h2>You're a Word Star!</h2><p>每次答对都有英文鼓励！新的关卡会继续增加。</p></div><div class="statsline">${badge('获得星星 '+stars()+' 枚')}${badge('已完成独立题目 '+awards.length+' 项')}</div><p class="muted">星星保存在当前设备浏览器本地。关闭浏览器后通常仍会保留；清除浏览器数据可能会重置记录。</p><button class="mainbtn" data-go="home">Back to Adventure</button></section>`}
function renderSettings(){
 const wordReady=Object.keys(words).filter(w=>hasHuman('word:'+w)).length;
 const praiseReady=Array.from({length:8},(_,i)=>hasHuman('praise:'+(i+1))).filter(Boolean).length;
 view.innerHTML=`<section class="panel">${getPanel('🎙️ 真人配音素材库','PARENT SETTINGS','home')}
 ${mentor('alpha','Let’s listen and learn!')}
 <div class="statsline">${badge('单词真人录音 '+wordReady+' / '+Object.keys(words).length)}${badge('鼓励语录音 '+praiseReady+' / 8')}</div>
 <p class="settingnote"><b>重要：此版本严格禁用系统合成朗读和 AI 配音。</b> 当前安装包没有预装真人录音，导入之前是静音状态；不会把机械朗读伪装成真人发音。词卡、游戏、星星奖励仍然能正常使用。</p>
 <div class="audio-panel"><strong>📁 批量导入真人录音</strong>
 <p class="settingnote">可以一次选取多段 MP3、M4A、WAV、OGG 音频。支持原始文件名 En-us-cat.ogg（自动匹配 cat）。其他命名规则：<code>word_cat.mp3</code>、<code>definition_cat.mp3</code>、<code>sentence_cat.mp3</code>、<code>praise_1.mp3</code> … <code>praise_8.mp3</code>。所有音频应为你录制或已有明确许可的真人声音。</p>
 <label class="filebox">📥 选择多个真人音频文件<input type="file" id="bulkAudioImport" accept="audio/*,.ogg,.oga,.mp3,.wav,.m4a,.aac" multiple /></label>
 <p class="settingnote">导入后保存在此应用自己的本地储存区。无需上传服务器。建议在安卓 App 中使用以避免普通浏览器的文件储存限制。</p></div>
 <div class="mini-row"><button class="flatbtn blue" id="testVoice">▶️ Test human praise #1</button><button class="flatbtn" data-go="home">返回首页</button></div>
 </section>`;
}
function renderSearchResults(value){const q=String(value||'').toLowerCase().trim();const el=$('#searchResult');if(!el)return;if(!q){el.innerHTML='<p class="muted">输入字母，即可搜索现有单词。</p>';return}const arr=Object.values(words).filter(w=>w.word.includes(q)).slice(0,20);el.innerHTML=arr.length?arr.map(w=>`<button data-find="${esc(w.word)}"><span class="emoji">${esc(w.emoji)}</span><span>${esc(w.word)}<small style="display:block;color:#7892af">🃏 翻开看看</small></span></button>`).join(''):'<p class="muted">当前词库没有这个词；可以在 JSON 里继续扩充。</p>'}
function render(){saveProgress();switch(ST.page){case 'home':renderHome();break;case 'library':renderLibrary();renderSearchResults('');break;case 'hub':renderHub();break;case 'cards':renderCards();break;case 'game':renderGame();break;case 'complete':renderComplete();break;case 'rewards':renderRewards();break;case 'settings':renderSettings();break;default:renderHome()} }
function onClick(e){const b=e.target.closest('button,[data-go],[data-family],[data-mode],[data-index],[data-activity],[data-carddir]');if(!b)return;
if(b.dataset.go){if(b.dataset.go==='library')return toLibrary(ST.mode);return go(b.dataset.go)}
if(b.dataset.mode)return toLibrary(b.dataset.mode);
if(b.dataset.cat){ST.category=b.dataset.cat;return render()}
if(b.dataset.family)return selectFamily(b.dataset.family);
if(b.dataset.find){const w=word(b.dataset.find),f=ready.find(f=>f.words.includes(w.word));ST.family=f.id;ST.wordIndex=f.words.indexOf(w.word);ST.flipped=false;return go('cards')}
if(b.dataset.activity){if(b.dataset.activity==='cards'){ST.wordIndex=0;ST.flipped=false;return go('cards')}return startGame(b.dataset.activity)}
if(b.id==='flip'){ST.flipped=!ST.flipped;b.classList.toggle('flipped',ST.flipped);b.setAttribute('aria-pressed',String(ST.flipped));return}
if(b.dataset.index!==undefined){ST.wordIndex=Number(b.dataset.index);ST.flipped=false;return render()}
if(b.dataset.carddir){ST.wordIndex=(ST.wordIndex+Number(b.dataset.carddir)+curFamily().words.length)%curFamily().words.length;ST.flipped=false;return render()}
if(b.dataset.sayword)return sayWord(b.dataset.sayword);
if(b.dataset.saymeaning)return sayMeaning(b.dataset.saymeaning);
if(b.dataset.saytext)return playAudioText(b.dataset.saytext);
if(b.dataset.answer)return checkAnswer(b.dataset.answer);
if(b.dataset.num)return checkAnswer(b.dataset.num);
if(b.dataset.next)return taskNext();
if(b.dataset.tile!==undefined){if(Date.now()<ignoreTileClickUntil)return;return fillTile(Number(b.dataset.tile))}
if(b.dataset.undo==='spell')return undoSpell();
if(b.dataset.reset==='spell'){ST.spellSlots=[];ST.usedTiles=[];ST.feedback='';return render()}
if(b.dataset.token!==undefined)return takeToken(Number(b.dataset.token));
if(b.dataset.unpick!==undefined)return unpickToken(Number(b.dataset.unpick));
if(b.dataset.reset==='build'){ST.builderPicked=[];ST.feedback='';return render()}
if(b.id==='testVoice')return playHuman('praise:1');
}
$('#app').addEventListener('click',onClick);
// Delegated text search and settings event handling.
view.addEventListener('input',e=>{if(e.target.id==='wordSearch')renderSearchResults(e.target.value)});
view.addEventListener('change',async e=>{
 if(e.target.dataset.importword){const file=e.target.files?.[0];if(file)await importRecordedAudio('word:'+e.target.dataset.importword,file)}
 if(e.target.id==='bulkAudioImport'){
  const files=Array.from(e.target.files||[]);let good=0;
  for(const file of files){
   // Support app's native names AND original Commons names such as En-us-cat.ogg.
   let m=/^(word|definition|sentence|praise)[_-]([a-z0-9]+)\.(mp3|wav|ogg|oga|m4a|aac)$/i.exec(file.name);
   let key=m ? m[1].toLowerCase()+':'+m[2].toLowerCase() : null;
   if(!key){m=/^en[-_]us[-_]([a-z]+)\.(mp3|wav|ogg|oga|m4a|aac)$/i.exec(file.name);
    if(m && words[m[1].toLowerCase()])key='word:'+m[1].toLowerCase();}
   if(!key)continue;
   if(key.startsWith('word:')&&!words[key.slice(5)])continue;
   if(await importRecordedAudio(key,file,true))good++;
  }
  showToast('成功导入 '+good+' / '+files.length+' 段录音。未识别的请用单词卡单独导入');render();
 }
});
// Pointer drag: press a letter, move over any empty slot, release.
let drag=null;let ignoreTileClickUntil=0;
view.addEventListener('pointerdown',e=>{const tile=e.target.closest('[data-tile]');if(!tile||ST.answered)return;drag={index:Number(tile.dataset.tile),startX:e.clientX,startY:e.clientY,active:false,pointerId:e.pointerId,clone:null};try{tile.setPointerCapture(e.pointerId)}catch(_){} });
view.addEventListener('pointermove',e=>{if(!drag||e.pointerId!==drag.pointerId)return;const dx=e.clientX-drag.startX,dy=e.clientY-drag.startY;if(!drag.active&&Math.hypot(dx,dy)>9){drag.active=true;const src=view.querySelector(`[data-tile="${drag.index}"]`);if(src){const ghost=src.cloneNode(true);ghost.classList.add('tile-ghost');ghost.removeAttribute('data-tile');document.body.appendChild(ghost);drag.clone=ghost}}if(drag.active&&drag.clone){drag.clone.style.left=e.clientX+'px';drag.clone.style.top=e.clientY+'px';const under=document.elementFromPoint(e.clientX,e.clientY);view.querySelectorAll('[data-slot]').forEach(x=>x.classList.toggle('drop',x===under||x.contains(under)))}});
view.addEventListener('pointerup',e=>{if(!drag||e.pointerId!==drag.pointerId)return;const d=drag;drag=null;d.clone?.remove();view.querySelectorAll('[data-slot]').forEach(x=>x.classList.remove('drop'));if(d.active){ignoreTileClickUntil=Date.now()+500;const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-slot]');if(target)fillTile(d.index,Number(target.dataset.slot))}});
view.addEventListener('pointercancel',()=>{drag?.clone?.remove();drag=null});
// An IndexedDB store holds user-imported audio blobs when the browser supports it.
let dbPromise=null;
function openDB(){if(!('indexedDB' in window))return Promise.resolve(null);if(dbPromise)return dbPromise;dbPromise=new Promise(resolve=>{try{const r=indexedDB.open('phonics-audio-v1',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('clips'))r.result.createObjectStore('clips')};r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null);r.onblocked=()=>resolve(null)}catch(e){resolve(null)}});return dbPromise}
async function loadRecordedAudio(){let db=await openDB();if(!db)return;try{const tx=db.transaction('clips','readonly');const store=tx.objectStore('clips');const req=store.openCursor();req.onsuccess=()=>{const cursor=req.result;if(!cursor)return;const val=cursor.value;if(val instanceof Blob){if(audioClips[cursor.key])URL.revokeObjectURL(audioClips[cursor.key]);audioClips[cursor.key]=URL.createObjectURL(val)}cursor.continue()}}catch(e){}}
async function importRecordedAudio(key,file,quiet=false){const ext=(file.name.split('.').pop()||'').toLowerCase();const isAudio=/^audio\//.test(file.type)||file.type==='application/ogg'||['mp3','wav','ogg','oga','m4a','aac'].includes(ext);if(!isAudio){if(!quiet)showToast('文件不是支持的音频格式：'+file.name);return false}if(file.size>6*1024*1024){if(!quiet)showToast('请导入小于6MB的单段音频');return false}const db=await openDB();if(db){try{await new Promise((resolve,reject)=>{const tx=db.transaction('clips','readwrite');const r=tx.objectStore('clips').put(file,key);r.onsuccess=resolve;r.onerror=reject});!quiet&&showToast('已导入真人录音，点击 Listen 试听')}catch(e){!quiet&&showToast('已加入本次游戏；可能不能长期保存')}}else !quiet&&showToast('已导入，重启可能需再导入');if(audioClips[key])URL.revokeObjectURL(audioClips[key]);audioClips[key]=URL.createObjectURL(file);return true;}
// Keep the sample cards easy to swipe horizontally on touch screens.
let sw=null;view.addEventListener('touchstart',e=>{if(ST.page!=='cards'||!e.touches[0])return;sw={x:e.touches[0].clientX,y:e.touches[0].clientY}},{passive:true});view.addEventListener('touchend',e=>{if(ST.page!=='cards'||!sw||!e.changedTouches[0])return;let dx=e.changedTouches[0].clientX-sw.x,dy=e.changedTouches[0].clientY-sw.y;sw=null;if(Math.abs(dx)>90&&Math.abs(dx)>Math.abs(dy)*1.8){ST.wordIndex=(ST.wordIndex+(dx<0?1:-1)+curFamily().words.length)%curFamily().words.length;ST.flipped=false;render()}},{passive:true});

render();loadRecordedAudio();
})();
