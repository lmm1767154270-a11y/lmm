# Phonics Adventure · 英语自然拼读互动游戏

首版版本：0.3.0（2026-11-17）  
适用：亲子共玩，安卓、iPad、电脑浏览器；优先按词族逐步使用。

## 1. 手机上怎么玩

1. 下载 `Phonics_Adventure_手机版_完整版.html`。
2. 在文件管理器中找到该文件，选择“使用浏览器打开”。如果手机不允许直接从下载目录打开 HTML，可以借助支持本地 HTML 的文件浏览器，或者将文件放到自己信任的静态网站上用浏览器访问。
3. 选择三个角色之一，再选择拼读类别和词族。首页提供 `-ip`、`-at`、`-ock`、`ai` 四个快速入口。
4. 在词族主页任选游戏：Flip & Discover、Picture Match、Rhyme Rescue 或 Find the Pattern、Spell It、Sound Detective、Sentence Power、Build a Sentence。
5. 点击单词卡翻面；拼词关卡支持点字母或将字母拖到空格。每题答对都有庆祝特效、英文鼓励，并可获得一颗星星（星星为每种独立题目首次答对计一次）。

普通游戏和图片可以在没有网络时运行。语音能否离线播放取决于手机系统是否已有可用的英语音色。

## 2. 教学角色

- **Ruby**：原创红粉色短发女孩。负责 Word Family Rescue、押韵词、单词翻卡。
- **Pip**：原创戴绿色眼镜的小猪。负责 Alphabet Adventure、字母拼写和音素数量。
- **Nova**：原创蓝色披风男孩。负责 Sentence Power、完整句理解和拼句。

角色不是《Super Why!》原版的官方形象，也不代表有动画 IP 的授权或官方合作。

## 3. 词库和素材完整度

- **262 个不重复单词**：每个具有 `word`, `emoji`, `definition`, `sentence`, `categories`, `patterns`, `sounds` 等字段。
- **66 组可玩的拼读分组**：涵盖短元音、Magic e、元音组合、R-controlled vowels、辅音字母组合、辅音连缀与进阶词族。
- **66 组待扩充分组**：仅有分类占位，不显示成可玩项目。
- **12 张 -ip 词族原创情景插画**：dip, sip, zip, lip, tip, rip, chip, ship, trip, flip, clip, hip。
- 其他单词是对应的**图像标记 / emoji 示意**，不是独立精绘插画。后续可陆续为它们制作原创插画。
- **120 个单词有用于数音素的明确音素分段**。没有分段的数据不会被强行用于数音素游戏。
- 给学前儿童的词库不等于“学前所有单词都已覆盖”；未完成的语音例外、词形变化、多义词、学前高频不规则词需要后续分批校对。

## 4. 音频：重要说明

内置系统使用浏览器 Web Speech API / `speechSynthesis` 朗读英文。它是**合成语音，不是真人录音**。实际口音、清晰度与自然程度依赖手机安装的语音包，不保证每部手机都达到母语真人效果。

- 点击右上角 ⚙️，可以启用/关闭设备朗读，调整速度和选择可用英语音色。
- 每次答对会选择一条不同的英文鼓励语并用设备语音朗读，如 “Great job!” / “You got it!”。
- 在单词翻卡页面可以导入用户自己拥有合法使用权的真人发音录音。支持时保存在浏览器 IndexedDB 数据库中。浏览器禁用或清除本地数据会影响存储；在 file:// 环境中，不同浏览器限制可能不同。
- **本包没有打包第三方真人配音文件**，也不会将合成语音误称为真人。想要完全真人发音，需要先取得授权音源，再逐词导入、注明授权信息或修改 `app.js` / `wordbank.json` 增加规范音频映射。

音源权限：请只使用自己录制或合法授权的音频，尤其不要未经许可使用动画角色原声配音。

## 5. 可编辑源代码目录

```
Phonics_Adventure_Source/
  README_使用说明.md
  seed_bank.py             初始词库脚本（不修改代码也可直接编辑 wordbank.json）
  wordbank.json            可编辑英语单词和词族数据
  app.template.html        HTML 网页骨架
  styles.css               全部页面样式
  app.js                   全部交互逻辑、奖励和语音处理
  build.py                 构建单文件 HTML
  audit.py                 数据一致性检查
  test_game.py             基本浏览器交互回归测试
  assets/
    ruby.png pip.png nova.png   三个原创卡通角色
    dip.webp ... hip.webp      12张 -ip 词族插画
  audio/
    README.txt             真人录音资源待完善
```

## 6. 电脑上改词库与扩充内容

`wordbank.json` 是当前网页实际加载的数据。编辑 JSON 后，运行：

```bash
python build.py
python audit.py
```

其中 `build.py` 会在上一层生成 `Phonics_Adventure_手机版_完整版.html`。不要在已有单词字段中随意改 id，否则可能导致词族引用失效。

如果想增加词族，推荐在 `seed_bank.py` 中按 `group(category, pattern, lines, label)` 格式新增单词及词族，运行：

```bash
python seed_bank.py
python build.py
python audit.py
```

**注意：运行 `seed_bank.py` 会重新生成并覆盖 `wordbank.json`**；如果只修改 JSON，就不需要运行 `seed_bank.py`。

仅使用 Python 标准库即可构建。浏览器交互自动测试 `test_game.py` 依赖 Playwright 和 Chromium；可以不运行。

## 7. 建议的下一步开发任务

1. 完成学前高频词的人工筛选：补充 -am、-ack、-ash、-ill、-ank、-ing、-oil、-oin、-oint、-oice、-ight、-ain 等常见模式。遇到同一拼写但不同读音的单词，要标注例外，不混入错误的押韵练习。
2. 逐步把剩余的 emoji 图像标记替换成统一风格的原创场景插画，注意图像与所教词义一致。
3. 按词条记录合法授权的真人音频、朗读者、授权名称、来源网址、发音地区与审核状态；允许关闭全部系统合成发声。
4. 在 Sentence Power 中，为更多词补充“单词 → 短语 → 完整句”三级表达示范与妈妈引导游戏。
5. 将“儿童高频不规则词”另作 Sight Words 游戏，而非硬分类到规则 phonics 词族。

## 8. 开发原则

仅设计原创角色，不复制原版《Super Why!》角色及动画画面；不内置无授权的配音。为自然拼读分类保留区域口音和不规则读音说明，不能把所有拼写近似的单词直接当作同韵词。词库量不应优先于解释、图像、发音和音素校对准确度。
