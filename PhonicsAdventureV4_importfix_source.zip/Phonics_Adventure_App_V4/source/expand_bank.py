"""Safely merge hand-curated preschool phonics additions into the V3 wordbank.
Usage: python expand_bank.py
"""
from pathlib import Path
import json,re
P=Path(__file__).parent
src=P/'wordbank.json'
bank=json.loads(src.read_text('utf-8'))
# Keep the legacy wordbank for auditability.
baseline=P/'wordbank_v3.json'
if not baseline.exists(): baseline.write_text(src.read_text('utf-8'),encoding='utf-8')
else: bank=json.loads(baseline.read_text('utf-8'))
lookup={(g['category'],g['pattern']):g for g in bank['families']}
cur=None; added=0; upgraded=0
for line in (P/'new_words.tsv').read_text(encoding='utf-8').splitlines():
    line=line.strip()
    if not line or line.startswith('#'):continue
    if line.startswith('[') and line.endswith(']'):
        category,pattern=line[1:-1].split('|',1)
        assert category in {c['id'] for c in bank['categories']}
        cur=lookup.get((category,pattern))
        if cur is None:
            cur={'id':f'{category}_{re.sub(r"[^a-zA-Z0-9]+","",pattern)}','category':category,'pattern':pattern,'label':pattern,'words':[],'status':'ready'}
            if cur['id'] in {x['id'] for x in bank['families']}:
                cur['id']+=f'_{len(bank["families"])}'
            bank['families'].append(cur)
            lookup[(category,pattern)]=cur
        if cur['status']=='planned': cur['status']='ready'; upgraded+=1
        continue
    values=line.split('|')
    assert len(values)==4,(cur,line)
    w,emoji,definition,sentence=values
    assert cur and w.isascii() and w.isalpha() and w.islower()
    assert definition.endswith('.') and sentence.endswith(('.', '!', '?'))
    if w not in bank['words']:
        bank['words'][w]={'id':w,'word':w,'emoji':emoji,'definition':definition,'sentence':sentence,'categories':[cur['category']],'patterns':[cur['pattern']],'sounds':[]}
        added+=1
    else:
        item=bank['words'][w]
        if cur['category'] not in item['categories']:item['categories'].append(cur['category'])
        if cur['pattern'] not in item['patterns']:item['patterns'].append(cur['pattern'])
    if w not in cur['words']:cur['words'].append(w)
# US-English pronunciation check: dog/log and fog/hog can have distinct rimes.
# Teach them as separate word-family subgroups instead of claiming all four rhyme.
og=lookup[('short','-og')]
og['words']=[w for w in og['words'] if w not in ('fog','hog')]
fog_group={'id':'short_og_fog_hog','category':'short','pattern':'-og (fog/hog)','label':'-og · fog / hog','words':['fog','hog'],'status':'ready','teachingNote':'In US English, some accents distinguish fog/hog from dog/log; do not mix the two groups in rhyme questions.'}
bank['families'].append(fog_group)
for wd in ('fog','hog'): bank['words'][wd]['patterns'].append(fog_group['pattern'])
for g in bank['families']:
    if g['status']=='ready' and len(g['words'])<2: raise ValueError(g)
# Fix earlier potentially confusing rules by assigning more precise categories/labels (no pronunciation claims without review).
notes={
 'short_-ail':'Words ending -ail; teach /eɪl/ with vowel team ai.',
 'short_-ight':'Words ending -ight; vowel spelling igh.',
 'short_-ind':'Words ending -ind often use long i; not a regular short-i family.',
 'short_-ost':'Words ending -ost may have long o in US English.',
 'short_-alk':'Silent L in walk, talk, chalk.',
 'short_-old':'Words ending -old often have long o.',
 'short_-ing extended':'Ending -ing /ɪŋ/.',
 'r_ear (bird)':'ear can sound /ɝ/ in learn, earth, search; accent may vary.',
 'r_ure':'Vowels before r need careful regional pronunciation checks.',
 'vowel_au':'Different accents/words may change the AU sound. Review each word.'}
for g in bank['families']:
    k=g['category']+'_'+g['pattern'];g['teachingNote']=notes.get(k,'')
# Some word form / picture disambiguation: reuse V3 definitions where the same word appears in multiple families.
# Expose accurate coverage counts to the app.
bank['metadata']={'version':'4.0','source':'hand-curated additions + V3','wordCount':len(bank['words']),'readyFamilies':sum(g['status']=='ready' for g in bank['families']),'plannedFamilies':sum(g['status']=='planned' for g in bank['families']), 'humanAudioWordCount':0, 'status':'audio recordings not bundled; human-only, silent until imported'}
src.write_text(json.dumps(bank,ensure_ascii=False,indent=2),encoding='utf-8')
print('WORDS',len(bank['words']),'ADDED',added,'READY',bank['metadata']['readyFamilies'],'PLANNED',bank['metadata']['plannedFamilies'],'UPGRADED',upgraded)
