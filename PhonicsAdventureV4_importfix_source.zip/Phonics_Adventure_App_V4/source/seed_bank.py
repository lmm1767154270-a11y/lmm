# -*- coding: utf-8 -*-
"""Curated starter words for a preschool phonics game.
Descriptions are simple American English written for pictured meanings.
Family labels are spelling patterns, not blanket guarantees about pronunciation.
"""
import json, pathlib

CATS=[
 {'id':'short','name':'Short vowels · 短元音','hint':'a / e / i / o / u；CVC 与常见结尾词族','color':'#fb7487','icon':'🍎'},
 {'id':'silent','name':'Magic e · 长元音','hint':'a_e / i_e / o_e / u_e（最后的 e 通常不发音）','color':'#f6ae4c','icon':'🪄'},
 {'id':'vowel','name':'Vowel teams · 元音组合','hint':'ai / ay / ee / ea / oa / igh / oi / oy 等','color':'#45b7c3','icon':'🌈'},
 {'id':'r','name':'R-controlled · R控制元音','hint':'ar / or / er / ir / ur 等美式英语规律','color':'#ab83dc','icon':'🦁'},
 {'id':'digraph','name':'Digraphs · 辅音字母组合','hint':'sh / ch / th / wh / ng / ck','color':'#88bd69','icon':'🐷'},
 {'id':'blend','name':'Blends · 辅音连缀','hint':'bl / cl / fl / br / tr / st 等，两个辅音都要发出','color':'#5e99db','icon':'🚂'},
 {'id':'advanced','name':'More patterns · 进阶拼读','hint':'学前后期接触：-old / -all / -tch / -dge / ear 等','color':'#cc8b9c','icon':'⭐'},
]
WORDS={};FAMILIES=[]
def group(cat,pattern,lines, label=None):
  ids=[]
  for row in lines.strip().splitlines():
    if not row.strip() or row.lstrip().startswith('#'):continue
    chunks=[x.strip() for x in row.split('|')]
    assert len(chunks)==4,(pattern,row,chunks)
    w,emoji,definition,sentence=chunks
    assert w.isalpha() and w.islower() and emoji and definition.endswith(('.', '!', '?')) and sentence.endswith(('.', '!', '?')),(pattern,w)
    if w not in WORDS:
      WORDS[w]={'id':w,'word':w,'emoji':emoji,'definition':definition,'sentence':sentence,'categories':[cat], 'patterns':[pattern]}
    else:
      if pattern not in WORDS[w]['patterns']: WORDS[w]['patterns'].append(pattern)
      if cat not in WORDS[w]['categories']: WORDS[w]['categories'].append(cat)
    ids.append(w)
  assert len(ids)>=2,(cat,pattern)
  FAMILIES.append({'id':f'{cat}_{pattern.replace(" ","")}', 'category':cat,'pattern':pattern,'label':label or pattern,'words':ids,'status':'ready'})

# Short vowels / simple word families. Most are easy-to-picture concrete senses.
group('short','-ip', '''
dip|🍪|Put something into a liquid and take it out.|Dip the cookie in milk.
sip|🥤|Drink a little at a time.|Take a small sip of water.
zip|🧥|Close a zipper.|Zip up your jacket.
lip|👄|One soft edge of your mouth.|Touch your top lip.
tip|✏️|The pointed end of something.|Look at the tip of the pencil.
rip|📄|Tear something into pieces.|Do not rip the paper.
chip|🥔|A thin, crunchy snack.|I have a potato chip.
ship|⛵|A big boat that sails on water.|The ship sails on the sea.
trip|🧸|Stumble over something.|Be careful not to trip.
flip|🥞|Turn something over.|Flip the pancake.
clip|🎀|A small thing that holds something in place.|Put the clip in your hair.
hip|🕺|The side of your body above your leg.|Put your hands on your hips.
''')
group('short','-at','''
cat|🐱|A small animal that says meow.|The cat is on the mat.
bat|🦇|An animal that flies at night.|The bat can fly.
hat|🎩|Something you wear on your head.|Put on your hat.
mat|🧘|A small piece you can sit or stand on.|Sit on the mat.
rat|🐀|A small animal with a long tail.|The rat runs away.
sat|🪑|The past tense of sit.|She sat on a chair.
''')
group('short','-an','''
man|👨|An adult male person.|The man has a bag.
pan|🍳|A flat dish for cooking food.|The egg is in the pan.
fan|🪭|Something that moves air to cool you.|The fan blows cool air.
can|🥫|A metal container for food or drinks.|Open the can of beans.
van|🚐|A large vehicle for carrying people or things.|The van is blue.
ran|🏃|The past tense of run.|He ran to the tree.
''')
group('short','-ap','''
cap|🧢|A soft hat with a brim.|I wear a red cap.
map|🗺️|A picture that shows where places are.|Find the park on the map.
nap|😴|A short sleep in the day.|The baby takes a nap.
tap|👆|Touch something lightly.|Tap the table gently.
lap|🧸|The top of your legs when you sit down.|The teddy sits on my lap.
''')
group('short','-ad','''
dad|👨‍👧|Another name for father.|Dad reads a book.
sad|😢|Feeling unhappy.|The boy feels sad.
mad|😠|Feeling angry.|The girl feels mad.
pad|🗒️|A stack of paper for writing.|Draw on the pad.
''')
group('short','-en','''
hen|🐔|A grown female chicken.|The hen lays an egg.
pen|🖊️|A tool you write with.|The pen is blue.
ten|🔟|The number after nine.|I can count to ten.
den|🐻|An animal's little home.|The bear is in its den.
''')
group('short','-et','''
pet|🐕|An animal you look after at home.|I love my pet dog.
jet|✈️|A fast airplane.|The jet flies high.
net|🥅|A mesh used to catch or hold things.|The ball goes into the net.
wet|💦|Covered with water.|My shoes are wet.
vet|🩺|An animal doctor.|The vet helps the puppy.
''')
group('short','-ed','''
bed|🛏️|Something you sleep in.|It is time for bed.
red|🟥|The color of a strawberry.|The apple is red.
sled|🛷|Something you ride down a snowy hill.|The sled goes down the hill.
''')
group('short','-ig','''
pig|🐷|A farm animal with a snout.|The pig is pink.
wig|👩‍🦰|Hair you can wear on your head.|The clown wears a wig.
dig|🪏|Make a hole in the ground.|I dig with a shovel.
big|🐘|Large in size.|The elephant is big.
fig|🟣|A small sweet fruit.|The fig is sweet.
''')
group('short','-in','''
pin|📌|A little pointed thing used to hold items.|Pin the note to the board.
bin|🗑️|A container for rubbish or toys.|Put it in the bin.
fin|🦈|A flat part on a fish that helps it swim.|The fish has a fin.
tin|🥫|A small metal container.|The cookies are in a tin.
win|🏆|Come first in a game.|We can win the game.
''')
group('short','-it','''
sit|🪑|Rest on a chair or the ground.|Please sit here.
hit|🥁|Touch something with a quick strong move.|Hit the drum softly.
fit|🧩|Be the right shape or size.|The piece fits here.
kit|🧰|A set of tools or things for a job.|Open the art kit.
bit|🍪|A small piece of something.|Take a little bit.
''')
group('short','-ick','''
kick|⚽|Move your foot to strike something.|Kick the ball.
lick|🍦|Touch something with your tongue.|Lick the ice cream.
pick|🍎|Choose or take something.|Pick an apple.
sick|🤒|Not feeling well.|The puppy feels sick.
tick|✅|Make a short mark to show yes.|Put a tick beside it.
''')
group('short','-og','''
dog|🐶|An animal that barks.|The dog likes to run.
log|🪵|A thick piece of a tree trunk.|The log is heavy.
fog|🌫️|A cloud close to the ground.|I can see fog outside.
hog|🐖|A large pig.|The hog rolls in the mud.
''')
group('short','-ot','''
pot|🍲|A container for cooking food.|The soup is in the pot.
hot|♨️|Very warm or high in temperature.|The soup is hot.
dot|🔴|A small round mark.|Draw a red dot.
cot|🛏️|A small simple bed.|The baby sleeps in a cot.
lot|🧸🧸|A large amount of something.|We have a lot of toys.
''')
group('short','-op','''
hop|🐇|Jump on one foot or in little jumps.|The rabbit can hop.
pop|🎈|Break suddenly with a small sound.|The balloon can pop.
top|🔝|The highest part of something.|The bird is on top.
mop|🧹|A tool for cleaning a floor.|Mop the wet floor.
shop|🏬|A place where you buy things.|We go to the shop.
''')
group('short','-ock','''
sock|🧦|Something soft you wear on your foot.|Put on a sock.
rock|🪨|A hard piece of stone.|The rock is heavy.
clock|🕒|Something that tells the time.|Look at the clock.
block|🧱|A solid piece you can build with.|Stack the blocks.
lock|🔒|Something that keeps a door closed.|Close the lock.
''')
group('short','-ug','''
bug|🐞|A small crawling insect.|A bug is on the leaf.
mug|☕|A cup with a handle.|The mug is warm.
rug|🧶|A soft cover for the floor.|Sit on the rug.
hug|🧸|Wrap your arms around someone or something.|Give Teddy a hug.
jug|🫗|A container used for pouring drinks.|Pour water from the jug.
''')
group('short','-un','''
sun|☀️|The bright star that warms Earth.|The sun is shining.
run|🏃|Move fast on your feet.|I can run fast.
fun|🎉|Something you enjoy doing.|The game is fun.
bun|🥯|A small round bread roll.|I eat a bun.
''')
group('short','-ub','''
tub|🛁|A big container you can bathe in.|The duck is in the tub.
rub|👐|Move your hand back and forth on something.|Rub your hands together.
cub|🐻|A young bear or other wild animal.|The bear cub is little.
sub|🚢|A short name for a submarine.|The sub goes underwater.
''')
group('short','-uck','''
duck|🦆|A bird that swims and says quack.|The duck swims in the pond.
truck|🚚|A large vehicle that carries things.|The truck carries boxes.
luck|🍀|Good things happening by chance.|Good luck in the game.
stuck|🪁|Unable to move from a place.|The kite is stuck in the tree.
''')
group('short','-ump','''
jump|🦘|Push off the ground with your feet.|Jump over the line.
bump|🚗|A small raised place or a light knock.|The car goes over a bump.
lump|🪨|A small thick piece of something.|There is a lump of clay.
pump|🚲|A tool that pushes air or water.|Pump air into the tire.
''')
group('short','-ell','''
bell|🔔|Something that makes a ringing sound.|Ring the bell.
shell|🐚|A hard cover on some animals.|Find a shell on the beach.
well|🪣|A deep hole for getting water.|The bucket goes into the well.
''')
group('short','-and','''
hand|✋|The part at the end of your arm.|Raise your hand.
sand|🏖️|Tiny grains found on beaches.|Make a castle with sand.
band|🥁|A group of people who play music.|The band plays a song.
land|🏞️|The solid ground, not the sea.|The bird lands on the ground.
''')
group('short','-ink','''
pink|🩷|A light red color.|The flower is pink.
sink|🚰|A basin where you wash your hands.|Wash your hands in the sink.
link|🔗|A connection between two things.|Join the links together.
wink|😉|Close one eye for a moment.|Can you wink one eye?
''')
# Silent e, carefully using standard long vowel spelling examples.
group('silent','a_e','''
cake|🎂|A sweet food often eaten at parties.|We bake a cake.
lake|🏞️|A big area of water surrounded by land.|The boat is on the lake.
make|🛠️|Create something.|Let's make a paper boat.
game|🎲|An activity with rules you play for fun.|Let's play a game.
name|🏷️|The word people call you.|Write your name.
gate|🚪|A door in a fence.|Open the gate.
''', 'a_e · long a')
group('silent','i_e','''
bike|🚲|A bicycle you ride.|I ride my bike.
kite|🪁|A toy that flies in the wind.|Fly a kite.
time|⏰|What a clock measures.|It is playtime.
line|〰️|A long thin mark.|Draw a straight line.
pine|🌲|An evergreen tree with needles.|The pine tree is tall.
ride|🎠|Travel on something such as a bike.|Ride the pony.
''','i_e · long i')
group('silent','o_e','''
home|🏠|The place where you live.|Let's go home.
nose|👃|The part of your face used to smell.|Touch your nose.
rope|🪢|A thick strong string.|Hold the rope.
cone|🍦|A pointy shape like an ice-cream cone.|I have a cone.
note|📝|A short written message.|Write a note.
''','o_e · long o')
group('silent','u_e','''
cube|🧊|A shape with six equal square faces.|The block is a cube.
tube|🧴|A long hollow shape or container.|Squeeze the tube.
cute|🐱|Sweet or lovely to look at.|The kitten is cute.
mute|🔇|Turn the sound off.|Mute the sound.
''','u_e · long u / yoo')
# Vowel combinations. Regional pronunciation differences and exception lists live in guide.
group('vowel','ai','''
rain|🌧️|Water that falls from clouds.|The rain is falling.
train|🚂|A long vehicle that runs on tracks.|The train goes fast.
tail|🐈|A long part at the back of an animal.|The cat has a tail.
mail|✉️|Letters or parcels sent to people.|The mail is here.
paint|🎨|Colored liquid used to make pictures.|Paint a bright sun.
''')
group('vowel','ay','''
day|🌞|The time when it is light outside.|Today is a sunny day.
play|🧸|Do something for fun.|Let's play with blocks.
tray|🍽️|A flat thing for carrying food.|Put the cup on the tray.
stay|🏡|Remain in one place.|Stay close to me.
gray|🐘|A color between black and white.|The elephant is gray.
''')
group('vowel','ee','''
bee|🐝|A flying insect that makes honey.|The bee visits a flower.
tree|🌳|A tall plant with a trunk and branches.|The tree has green leaves.
feet|🦶|The parts of your body you stand on.|Wash your feet.
seed|🌱|A small thing that can grow into a plant.|Plant the seed.
sheep|🐑|A farm animal with wool.|The sheep eats grass.
''')
group('vowel','ea (long e)','''
sea|🌊|A large area of salty water.|The fish swims in the sea.
leaf|🍃|The flat green part of a plant.|A leaf falls down.
beach|🏖️|Sandy land next to the sea.|We play on the beach.
peach|🍑|A round soft fruit.|The peach is sweet.
''','ea · long e')
group('vowel','oa','''
boat|⛵|Something you travel in on water.|The boat is in the lake.
coat|🧥|Clothes you wear over your shirt.|Put on your coat.
goat|🐐|A farm animal with horns.|The goat eats grass.
road|🛣️|A path for cars and trucks.|The car is on the road.
soap|🧼|Something you use to wash.|Wash your hands with soap.
''')
group('vowel','ow (long o)','''
snow|❄️|Frozen white flakes falling from clouds.|The snow is soft.
grow|🌱|Become bigger or taller.|The little plant can grow.
blow|🌬️|Push air from your mouth or in the wind.|Blow the bubbles.
glow|✨|Give off soft light.|The stars glow at night.
''','ow · long o')
group('vowel','igh','''
night|🌙|The time when it is dark outside.|The moon shines at night.
light|💡|Something that helps you see.|Turn on the light.
right|➡️|The opposite of left, for direction.|Turn right at the sign.
bright|☀️|Giving lots of light.|The sun is bright.
''')
group('vowel','oo (long)','''
moon|🌕|The round object seen in the night sky.|The moon is bright.
spoon|🥄|Something you eat soup with.|Use a spoon for soup.
food|🍲|Things you eat to grow and live.|The food smells good.
pool|🏊|A place full of water for swimming.|Swim in the pool.
''','oo · /uː/')
group('vowel','oo (short)','''
book|📖|Pages with words or pictures to read.|Open the book.
look|👀|Use your eyes to see.|Look at the butterfly.
cook|🧑‍🍳|Make food using heat.|We cook dinner.
''','oo · /ʊ/')
group('vowel','oi','''
coin|🪙|A small round piece of money.|The coin is shiny.
boil|♨️|Heat water until it bubbles.|The water begins to boil.
soil|🪴|The earth where plants grow.|Put the seed in the soil.
point|👉|Show something with your finger.|Point to the door.
''')
group('vowel','oy','''
boy|👦|A young male child.|The boy is running.
toy|🧸|Something children play with.|This is my toy.
joy|😃|A feeling of great happiness.|Her face is full of joy.
''')
group('vowel','ou','''
cloud|☁️|A white or gray shape in the sky.|A cloud covers the sun.
loud|📣|Making a lot of sound.|The drum is loud.
round|⚽|Shaped like a circle or ball.|The ball is round.
mouse|🐭|A little animal with a long tail.|The mouse hides in a hole.
''','ou · /aʊ/')
group('vowel','ow (cow)','''
cow|🐄|A farm animal that gives milk.|The cow eats grass.
owl|🦉|A bird with big eyes that hunts at night.|The owl sits in a tree.
brown|🟫|The color of chocolate.|The bear is brown.
crown|👑|A special hat for a king or queen.|The crown is gold.
''','ow · /aʊ/')
group('vowel','aw','''
paw|🐾|An animal's foot.|The puppy lifts its paw.
saw|🪚|A tool used to cut wood.|The saw cuts wood.
jaw|🦷|The lower part of your mouth that moves.|Open and close your jaw.
''')
# R-controlled patterns in general American English.
group('r','ar','''
car|🚗|A small vehicle with four wheels.|The car goes down the road.
star|⭐|A bright object in the night sky.|I can see a star.
farm|🚜|A place where animals or crops are raised.|The cow lives on a farm.
park|🛝|An outdoor place where people play.|Let's go to the park.
''')
group('r','or','''
corn|🌽|A yellow vegetable with many kernels.|The corn is yellow.
fork|🍴|Something you use to pick up food.|Eat with a fork.
horn|📯|Something that makes a loud sound.|The horn goes beep.
storm|⛈️|Weather with strong wind and rain.|Stay inside during the storm.
''')
group('r','er','''
her|👧|A word used for a girl or woman.|This is her book.
fern|🌿|A leafy green plant.|A fern grows in the shade.
verb|💬|A word that tells what someone does.|Run is a verb.
''')
group('r','ir','''
bird|🐦|An animal with feathers and wings.|The bird can fly.
girl|👧|A young female child.|The girl rides a bike.
shirt|👕|Clothes you wear on your upper body.|Put on your shirt.
''')
group('r','ur','''
fur|🐻|Soft hair that covers many animals.|The bear has thick fur.
turn|↪️|Move to face a different direction.|Turn around slowly.
burn|🔥|Be damaged by fire or heat.|Do not touch the fire or you may burn.
hurt|🩹|Feel pain.|My knee hurts.
''')
group('r','air','''
hair|💇|What grows on top of your head.|Brush your hair.
chair|🪑|Something with a back for sitting.|Sit on the chair.
pair|👟|Two things that go together.|Find a pair of shoes.
''')
# Digraphs; individual patterns contain words where the combination makes a single consonant phoneme.
group('digraph','sh','''
ship|⛵|A big boat that sails on water.|The ship sails on the sea.
shop|🏬|A place where you buy things.|We go to the shop.
fish|🐟|An animal that lives in water.|The fish can swim.
dish|🍽️|A plate or bowl for food.|Wash the dish.
shell|🐚|A hard cover on some animals.|Find a shell on the beach.
''')
group('digraph','ch','''
chip|🥔|A thin, crunchy snack.|I have a potato chip.
chin|🙂|The bottom part of your face.|Touch your chin.
chat|💬|Talk with someone.|Let's have a chat.
chop|🥕|Cut food into small pieces.|Chop the carrots.
chick|🐥|A baby chicken.|The chick is yellow.
''')
group('digraph','th (voiceless)','''
thin|📄|Not thick.|The paper is thin.
thick|📚|Not thin; wide from side to side.|This book is thick.
bath|🛁|Washing your body in water.|The baby takes a bath.
moth|🦋|A flying insect that looks like a butterfly.|The moth flies at night.
''','th · /θ/')
group('digraph','wh','''
whale|🐋|A very large animal that lives in the sea.|The whale swims in the ocean.
wheel|🛞|A round part that helps things roll.|The bike has two wheels.
whip|🥣|Mix or beat something quickly.|Whip the cream.
''')
group('digraph','ng','''
ring|💍|A round piece of jewelry worn on a finger.|The ring is gold.
sing|🎤|Make music with your voice.|Let's sing a song.
wing|🪽|A body part that helps birds fly.|The bird has a wing.
king|🤴|A male ruler in a story.|The king wears a crown.
''')
group('digraph','ck','''
duck|🦆|A bird that swims and says quack.|The duck swims in the pond.
sock|🧦|Something soft you wear on your foot.|Put on a sock.
back|🔙|The part of your body behind your chest.|My backpack is on my back.
neck|🦒|The part between your head and body.|The giraffe has a long neck.
kick|⚽|Move your foot to strike something.|Kick the ball.
''')
# Blends; unlike consonant digraphs, both consonant sounds remain.
group('blend','bl','''
black|⬛|The darkest color.|The cat is black.
blue|🔵|The color of a clear sky.|The sky is blue.
block|🧱|A solid piece you can build with.|Stack the blocks.
''')
group('blend','cl','''
clap|👏|Hit your hands together to make a sound.|Clap your hands.
clock|🕒|Something that tells the time.|Look at the clock.
cloud|☁️|A white or gray shape in the sky.|A cloud covers the sun.
''')
group('blend','fl','''
flag|🚩|A piece of cloth used as a sign.|Wave the flag.
flip|🥞|Turn something over.|Flip the pancake.
flower|🌼|The colorful part of a plant.|The flower is yellow.
''')
group('blend','br','''
brown|🟫|The color of chocolate.|The bear is brown.
brush|🪥|A tool with bristles for cleaning.|Brush your teeth.
bread|🍞|A food made from flour and baked.|I eat bread.
''')
group('blend','tr','''
tree|🌳|A tall plant with a trunk and branches.|The tree has green leaves.
train|🚂|A long vehicle that runs on tracks.|The train goes fast.
truck|🚚|A large vehicle that carries things.|The truck carries boxes.
trip|🧸|Stumble over something.|Be careful not to trip.
''')
group('blend','st','''
star|⭐|A bright object in the night sky.|I can see a star.
stop|🛑|Do not move any farther.|Stop at the red light.
step|👣|Move one foot forward.|Take one big step.
''')
group('blend','sm','''
smile|😊|Make a happy face with your mouth.|Smile for the photo.
smell|👃|Notice something with your nose.|Smell the flower.
smoke|🌫️|The gray cloud made by burning things.|The chimney has smoke.
''')
group('blend','sp','''
spoon|🥄|Something you eat soup with.|Use a spoon for soup.
spin|🌀|Turn around and around.|The top can spin.
spot|🟡|A small round mark or place.|Find the yellow spot.
''')
group('blend','dr','''
drum|🥁|Something you hit to make a beat.|Bang the drum.
dress|👗|A piece of clothing you wear.|The dress is yellow.
drop|💧|Let something fall down.|Do not drop the cup.
''')
# Important frequent patterns outside the regular beginner groups.
group('advanced','-all','''
ball|⚽|A round thing used for playing.|Throw the ball.
tall|🦒|High from the ground.|The giraffe is tall.
wall|🧱|A side of a room or building.|The clock is on the wall.
small|🐜|Not big.|The ant is small.
''')
group('advanced','-old','''
cold|🥶|Not warm.|My hands are cold.
gold|🥇|A shiny yellow metal.|The crown is made of gold.
fold|📄|Bend something over itself.|Fold the paper in half.
scold|☝️|Tell someone off for doing something wrong.|The teacher does not scold the child.
''')
group('advanced','ear (near)','''
ear|👂|The body part you hear with.|Touch your ear.
hear|👂|Notice a sound with your ears.|Can you hear the bell?
near|📍|Not far away.|The park is near our home.
''','ear · /ɪr/')

# Complete taxonomy scaffolding for later curation; NOT advertised as playable.
PLANNED={
 'short':['-am','-ag','-ash','-ack','-ang','-ank','-est','-end','-ing','-ill','-ink (extended)','-ust','-ush','-ush','-unk','-unk (extended)','-ox','-ob','-od'],
 'silent':['e_e (long e)','-ave','-ice','-ope','-ose','-une'],
 'vowel':['ea (short e)','ie (long i)','ie (long e)','ue','ew','au','-ook','-ould','-ought'],
 'r':['ore','ear (bear)','ear (bird)','ire','ure'],
 'digraph':['ph','tch','dge','th (voiced)'],
 'blend':['gl','pl','sl','cr','fr','gr','pr','sc','sk','sn','sw','tw','spr','str','scr'],
 'advanced':['-ight','-ind','-ost','-alk','-ould (special)','soft c','soft g','two-syllable words','unstressed schwa'],
}
PLANNED={k:list(dict.fromkeys(v)) for k,v in PLANNED.items()}
for cat,ps in PLANNED.items():
  for p in ps:
    # a planned rule can overlap with seeded groups; do not create duplicate displayed ids.
    if any(x['category']==cat and x['pattern']==p for x in FAMILIES):continue
    FAMILIES.append({'id':f'future_{cat}_{len(FAMILIES)}','category':cat,'pattern':p,'label':p,'words':[], 'status':'planned'})

# Phoneme chip sound segmentation for simple words. Explicit overrides help avoid bad automated claims.
SOUND_OVERRIDES={
 'ship':['sh','i','p'], 'chip':['ch','i','p'], 'chin':['ch','i','n'], 'chat':['ch','a','t'],
 'thin':['th','i','n'],'thick':['th','i','ck'],'fish':['f','i','sh'],'dish':['d','i','sh'],
 'duck':['d','u','ck'],'sock':['s','o','ck'],'rock':['r','o','ck'],'clock':['c','l','o','ck'],
 'shop':['sh','o','p'], 'shell':['sh','e','ll'], 'chick':['ch','i','ck'],
 'trip':['t','r','i','p'],'flip':['f','l','i','p'],'clip':['c','l','i','p'],
 'truck':['t','r','u','ck'],'brush':['b','r','u','sh'],
 'dog':['d','o','g'],'cat':['c','a','t'],'hat':['h','a','t'],'pig':['p','i','g'],
 'sun':['s','u','n'],'pen':['p','e','n'],'pot':['p','o','t'],
 'ring':['r','i','ng'],'sing':['s','i','ng'],'wing':['w','i','ng'],'king':['k','i','ng'],
 'pink':['p','i','ng','k'],'sink':['s','i','ng','k'],
 'jump':['j','u','m','p'],'hand':['h','a','n','d'],'bell':['b','e','ll'],
 'bee':['b','ee'],'tree':['t','r','ee'],'boat':['b','oa','t'],
 'rain':['r','ai','n'],'train':['t','r','ai','n'],
 'night':['n','igh','t'],'light':['l','igh','t'],
 'car':['c','ar'],'star':['s','t','ar'],
 'moon':['m','oo','n'],'book':['b','oo','k'],
}
# Other simple CVC words have transparently segmented single-letter phonemes.
for word,item in WORDS.items():
  if word in SOUND_OVERRIDES:
    item['sounds']=SOUND_OVERRIDES[word]
  elif len(word)==3 and 'short' in item['categories'] and all(ch in 'abcdefghijklmnopqrstuvwxyz' for ch in word):
    item['sounds']=list(word)
  else:
    item['sounds']=[]

# English teaching reminders: exceptions are kept OUTSIDE automated regularity claims.
DATA={
 'version':'0.3.0',
 'stage':'第一批经人工整理的示例词库；仍需逐步增补和复核',
 'categories':CATS,
 'families':FAMILIES,
 'words':WORDS,
 'notes':[
  '按拼写规律组织，不等于所有词都同音；不同口音可能有差异。',
  'oo 的 /uː/ 与 /ʊ/、ow 的 /oʊ/ 与 /aʊ/ 分开教学。',
  'er / ir / ur 在多数美式口音中经常合流，但拼写不同。',
  'sh/ch/th 这样的digraph常表示一个辅音音素；br/tr/fl这样的blend包含两个辅音音素。',
  '英语高频不规则词（one, two, said, the, was等）应单独作为视觉高频词教学，不强行塞入规则词族。',
  '解释与插画对应某一种具体义项，不保证一个单词全部词义。',
  '给学前儿童先练口语理解和解码，不要求一次掌握所有词库。'
 ]
}
path=pathlib.Path(__file__).with_name('wordbank.json')
path.write_text(json.dumps(DATA,ensure_ascii=False,indent=2),encoding='utf-8')
print('OUTPUT',path,'word count',len(WORDS),'ready families',len([f for f in FAMILIES if f['status']=='ready']),'planned families',len([f for f in FAMILIES if f['status']=='planned']))
