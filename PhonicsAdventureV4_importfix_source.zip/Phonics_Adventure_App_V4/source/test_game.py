from playwright.sync_api import sync_playwright
from pathlib import Path
import json, sys
import http.server, socketserver, threading, os
ROOT=Path(__file__).parent.parent
os.chdir(ROOT)
server=socketserver.TCPServer(('127.0.0.1',0),http.server.SimpleHTTPRequestHandler)
threading.Thread(target=server.serve_forever,daemon=True).start()
URL='http://127.0.0.1:'+str(server.server_address[1])+'/Phonics_Adventure_%E6%89%8B%E6%9C%BA%E7%89%88_%E5%AE%8C%E6%95%B4%E7%89%88.html'
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((ROOT/'Phonics_Adventure_手机版_完整版.html').read_text(encoding='utf-8'),wait_until='load')
 page.wait_for_selector('.hero')
 print('home modules',page.locator('.module').count())
 page.screenshot(path='/mnt/data/Phonics_Adventure_手机首页预览.png',full_page=True)
 page.locator('button[data-family="short_-ip"]').first.click()
 assert page.locator('.activity').count()==7
 page.locator('button[data-activity="cards"]').click()
 assert page.locator('.flipcard').count()==1
 page.locator('#flip').click()
 assert 'flipped' in page.locator('#flip').get_attribute('class');page.wait_for_timeout(700)
 assert 'Put something into a liquid' in page.content()
 page.screenshot(path='/mnt/data/Phonics_Adventure_翻卡预览.png',full_page=True)
 page.locator('button[data-go="hub"]').click()
 page.locator('button[data-activity="picture"]').click()
 q=page.locator('.task').inner_text()
 answer=page.locator('.task em').inner_text().rstrip('!')
 print('match prompt',q,answer)
 page.locator(f'button[data-answer="{answer}"]').click()
 assert page.locator('button[data-next]').count()==1
 page.locator('button[data-next]').click()
 page.locator('button[data-go="hub"]').click()
 page.locator('button[data-activity="rhyme"]').click()
 q=page.locator('button[data-answer]').all()
 assert len(q)>=2
 # Use correct answer by ready task data via DOM loaded JS closure isn't exposed; all same -ip, pick an ip answer different clue.
 opts=[el.get_attribute('data-answer') for el in q]
 cue=page.locator('.task em').inner_text()
 correct=next(x for x in opts if x in ['dip','sip','zip','lip','tip','rip','chip','ship','trip','flip','clip','hip'] and x!=cue)
 page.locator(f'button[data-answer="{correct}"]').click()
 assert page.locator('button[data-next]').count()==1
 page.locator('button[data-go="hub"]').click()
 page.locator('button[data-activity="spell"]').click()
 page.screenshot(path='/mnt/data/Phonics_Adventure_拼词预览.png',full_page=True)
 # choose target from definition picture - direct hidden inside rendered JS closure can't access; read via display audio button
 target=page.locator('[data-sayword]').first.get_attribute('data-sayword')
 print('spell target',target)
 for ch in target:
  opts=page.locator('button.tile:not(.used)')
  idx=next(el.get_attribute('data-tile') for el in opts.all() if el.inner_text().strip()==ch)
  page.locator(f'button[data-tile="{idx}"]').click()
 assert page.locator('button[data-next]').count()==1
 page.locator('button[data-go="hub"]').click()
 page.locator('button[data-activity="sentence"]').click()
 target=page.locator('[data-answer]').first.get_attribute('data-answer')
 current=[el.get_attribute('data-answer') for el in page.locator('[data-answer]').all()]
 # find image word rendered as icon aria label or alt
 pic_label=page.locator('.picture [aria-label], .picture img').first.get_attribute('aria-label') or page.locator('.picture img').first.get_attribute('alt')
 expected=next(w for w in current if w in pic_label)
 page.locator(f'button[data-answer="{expected}"]').click()
 assert page.locator('button[data-next]').count()==1
 page.locator('button[data-go="hub"]').click()
 page.locator('button[data-activity="build"]').click()
 # test current token sentence by retrieving expected from data-saytext
 sentence=page.locator('[data-saytext]').first.get_attribute('data-saytext')
 correct_tokens=__import__('re').findall(r"[\w']+",sentence)
 for ch in correct_tokens:
  opts=page.locator('button[data-token]:not([disabled])')
  idx=next(el.get_attribute('data-token') for el in opts.all() if el.inner_text().strip().lower()==ch.lower())
  page.locator(f'button[data-token="{idx}"]').click()
 assert page.locator('button[data-next]').count()==1
 print('sentence built:',sentence)
 # test audio settings
 page.locator('button[data-go="hub"]').click()
 page.locator('button[data-go="home"]').first.click()
 page.locator('button[data-go="settings"]').click()
 print('After settings',page.locator('h2').all_inner_texts(), 'errors',errors);page.screenshot(path='/mnt/data/Phonics_Adventure_设置预览.png',full_page=True);assert page.locator('#speechToggle').count()==1
 assert page.locator('#voiceSelect').count()==1
 print('errors',errors)
 assert not errors,errors
 browser.close()
 print('PASS ALL FLOW')
