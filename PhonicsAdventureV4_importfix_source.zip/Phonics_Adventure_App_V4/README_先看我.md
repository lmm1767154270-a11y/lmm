# Phonics Adventure V4 — 安卓小软件工程（尚未生成 APK）

## 本次实际交付

- 游戏升级为 525 个不重复词汇 / 175 个已填充拼读分组 / 7 个待填充分组。
- 保留三个原创角色与 7 种游戏玩法。-ip 的 12 张翻卡采用独立插画；其他词目前以可识别的 emoji 图像标记呈现，并非全部为精细插画。
- 翻卡背面含单词图像标记、英文解释；包含字母拼写、押韵、句子理解、星星奖励等。
- 严格真人录音模式：已禁用系统语音合成和 AI 配音。当前录音素材包为空（0 / 525 个单词，鼓励语 0 / 8）。没有真人录音的项目不会发声；答对仍可获得可视化星星奖励。**未完成“每个单词都是真人发音”的最终目标。**
- 已制作安卓原生 WebView 容器源码，所有游戏 HTML、图片、词库均封入安装包资产，不依赖网络。工程还没有在 Android SDK 下编译或真机测试 APK。

## 手机上怎样用

安卓 APK 必须在安装 Android SDK / Gradle 的电脑环境编译。现在此包内没有可安装 APK，切勿把 `.zip` 或 `.html` 当成 APK 安装。

若只是临时试玩，可下载 `Phonics_Adventure_V4_离线试玩.html`，用本地浏览器打开。你之前提到此方式可能打不开，因此**建议最终使用 APK**。

## 有电脑时怎样打包 APK

1. 安装 Android Studio（建议使用近期正式版）并安装 Android SDK Platform 35、Build Tools。
2. 用 Android Studio 选择 Open 打开本包中的 `android-app` 目录。
3. 让 IDE 使用 JDK 17，同步 Gradle（第一次需联网下载依赖）。
4. 选择 Build → Build APK(s)，完成后在 `android-app/app/build/outputs/apk/debug/app-debug.apk` 找到安装包。
5. 使用 USB / 文件传输把 APK 传到安卓手机安装。首次安装未签名商店应用，安卓可能提示来源确认。仅安装你自己构建或信任的安装包。

工程本身并不含 Gradle wrapper jar；用已经安装 Gradle 的环境或 Android Studio 配置本地 Gradle，或者在有 Gradle 的电脑上运行 `gradle wrapper --gradle-version 8.11.1` 后 `./gradlew assembleDebug`。

> 备注：当前会话环境没有 Android SDK / Gradle，无法为你生成已验证安装的 APK。源码和构建指南是真实可编辑的，但尚未真机运行测试。

## 真人录音如何实现

- 打开 `真人录音制作清单.csv`，里面有 525 个单词及各自的解释、句子，另有 8 条鼓励语，共 1,583 段待配音。
- 可由成人美式英语母语者录制，或使用明确许可授权的真人录音。必须尊重相应许可，注明原作者及许可。
- 录音命名示例：`word_cat.mp3`、`definition_cat.mp3`、`sentence_cat.mp3`、`praise_1.mp3`。
- 游戏设置页支持从手机导入多段音频，优先使用用户导入的真人录音。导入的内容保存在该 App 的本地存储中。
- 若要将自己录好的文件直接内置到 APK，把录音放到 `source/voice_pack` 中，运行 `python source/build.py`，再重新编译 APK；本地构建脚本会将它们封装进去。
- 禁止把系统 TTS 或合成声音命名为真人录音。

## 技术来源与测试

- 原有 HTML / JS 游戏保留并在 source 中增量更新。
- source/new_words.tsv：本轮手工编写、可审核的词汇和英文释义。
- source/expand_bank.py：依据 V3 基线合并词库，重复执行无重复词累加。
- source/build.py：将网页、卡片图像、（可选）录音封装为离线 HTML 和 Android assets。
- source/audit_v4.py：静态词库结构验证。
- source/test_v4.py：Playwright 模拟安卓触屏测试（并不等于 APK 真机测试）。

## 教学建议

先玩 -at / -ip / -ock 等短元音规律，再逐步过渡 magic e、元音组合、R-controlled、辅音组合和较复杂拼读规则。注意同字母组合也可能存在不同发音，不能仅依据结尾拼写判断所有单词押韵。婴幼儿学习时应以听音、意义理解和少量完整句输出为主。

## 用 GitHub 自动打包（可选）

如果将整个 `Phonics_Adventure_App_V4` 文件夹作为一个 GitHub 仓库根目录上传，`.github/workflows/build-apk.yml` 可以在 GitHub Actions 的 `Build offline Phonics APK` 中手动触发，云端安装 SDK 并构建调试安装包，构建成功后在该次 Actions 运行的 Artifacts 中获取 `Phonics-Adventure-V4-debug-apk`。
此流程已编写，但在当前环境**没有实际运行 GitHub Actions / APK 安装测试**。
