Phonics Adventure V4 真人配音修复包

完成的程序修复：
1. 句子播放会正确匹配 sentence_单词名.mp3（修正之前 text_句子全文 查找失败的问题）。
2. 语音鼓励只在实际存在的真人鼓励录音中随机选取；避免空文件随机静音。
3. source/audit_voice.py 自动报告词语、解释、句子、鼓励语的录音覆盖率。
4. 源码 build.py 已支持 source/voice_pack/ 目录，务必在 Gradle 编译前执行 build.py。

尚未完成：525词真人发音、525条英文解释、525句示例句子、8条鼓励语，合计1583条。此包没有伪造录音。

先让美式英语母语者录制（或从满足许可的真人音频来源合法获取）录音，按 source/voice_pack/README_真人音频命名.txt 命名并添加，再运行：
python3 source/audit_voice.py
python3 source/build.py

在 GitHub 手机端打包：
- 用含音频的这个项目替换旧ZIP，并将仓库 .github/workflows/build-apk.yml 更新为本包中提供的版本；工作流会重新生成嵌入录音的HTML，而不是复用旧静音版。
- Actions -> Build Phonics APK With Voice Pack -> Run workflow。

说明：当前环境无法下载、核验及授权近1600条真实人声录音，也没有在本地编译安卓APK。
