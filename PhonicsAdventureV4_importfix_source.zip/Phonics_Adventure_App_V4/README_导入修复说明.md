# V4.1 安卓真人录音导入兼容性修复

## 解决的问题
- Android 文件选择器不再只接受 audio/* MIME 类型，下载的 .ogg 文件可以在所有文件中选择。
- 单词卡允许任意原始文件名选择录音，包括 `En-us-cat.ogg`。
- 设置内的批量导入自动识别 Wikimedia Commons 原始的 `En-us-cat.ogg` 文件名，并关联单词 `cat`。
- 即使系统将 .ogg 标为 `application/ogg`、`application/octet-stream` 或没有音频 MIME，仍可依据受支持的文件扩展名识别。
- 修复先前版本例句音频键匹配问题；但录音素材仍需有授权地另行提供。未提供真人录音时不会自动合成声音。

## 手机 Github 更新
1. 将 PhonicsAdventureV4_importfix_source.zip 上传到已有 Github 仓库根目录。
2. 编辑 `.github/workflows/build-apk.yml`，把内容替换为随包提供的 build-apk-importfix.yml。
3. GitHub Actions 中运行 Build Phonics APK V4.1，成功后下载新的 APK artifact。
4. 本调试版使用独立的 applicationId `com.phonics.adventure.v41`，因此可与旧版并存，不需要卸载旧版。旧版内的学习记录和音频不会自动迁移到 V4.1。

## 试听
V4.1 打开 Word Family Rescue → -at → Flip & Discover → cat → ➕ 为 cat 导入真人发音，选择下载的原始 En-us-cat.ogg，再点击 Listen。
也可以使用 Settings → 批量导入，直接选择 En-us-cat.ogg，无须更名。

## 限制
只修复导入功能，不提供新录音。Android APK 编译尚未在当前环境完成；已用 Chromium 手机模拟器验证 JavaScript 的文件导入与识别逻辑。
