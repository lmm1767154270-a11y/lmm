package com.phonics.adventure;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ClipData;
import android.net.Uri;
import android.graphics.Color;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.Set;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** V4.3 offline wrapper. Words: human recordings only.
 * Definitions, sentences and praise: local en-US Android TextToSpeech fallback.
 * Neither imported audio nor speech content is sent to the app's servers. */
public final class MainActivity extends Activity {
    private static final int REQUEST_NATIVE_AUDIO = 501;
    private static final int REQUEST_WEB_FILE = 502;
    private static final long MAX_CLIP = 6L * 1024L * 1024L;
    private static final String[] EXTENSIONS = {"ogg", "oga", "mp3", "wav", "m4a", "aac"};
    private static final Pattern KEY_PATTERN = Pattern.compile("^(word|definition|sentence):[a-z]{1,30}$|^praise:[1-8]$");
    private static final Pattern NAMED_PATTERN = Pattern.compile("^(word|definition|sentence|praise)[_-]([a-z0-9]+)\\.(ogg|oga|mp3|wav|m4a|aac)$",Pattern.CASE_INSENSITIVE);
    private static final Pattern COMMONS_PATTERN = Pattern.compile("^en[-_]us[-_]([a-z]+)\\.(ogg|oga|mp3|wav|m4a|aac)$",Pattern.CASE_INSENSITIVE);
    private WebView webView;
    private MediaPlayer playing;
    private TextToSpeech tts;
    private volatile boolean ttsReady=false;
    private volatile String ttsInfo="美式英语语音初始化中…";
    private boolean bulkPending;
    private String singlePendingKey;
    private ValueCallback<Uri[]> legacyCallback;
    private final Object mediaLock = new Object();
    private File clipDir;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(71,156,208));
        getWindow().setNavigationBarColor(Color.rgb(57,113,171));
        clipDir = new File(getFilesDir(), "human_audio");
        clipDir.mkdirs();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(238,248,255));
        WebSettings cfg = webView.getSettings();
        cfg.setJavaScriptEnabled(true);
        cfg.setDomStorageEnabled(true);
        cfg.setDatabaseEnabled(true);
        cfg.setAllowContentAccess(true);
        cfg.setAllowFileAccessFromFileURLs(false);
        cfg.setAllowUniversalAccessFromFileURLs(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return !"file:///android_asset/index.html".equals(req.getUrl().toString());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (legacyCallback != null) legacyCallback.onReceiveValue(null);
                legacyCallback=cb;
                try {
                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    pick.setType("*/*");
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE);
                    pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(pick, REQUEST_WEB_FILE);
                } catch(Exception ex) {
                    legacyCallback.onReceiveValue(null);
                    legacyCallback=null;
                }
                return true;
            }
        });
        // Only the locally bundled asset is loaded; no remote content is permitted.
        webView.addJavascriptInterface(new NativeVoice(), "NativeAudio");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        initOfflineSpeech();
    }

    private void initOfflineSpeech(){
        tts = new TextToSpeech(this, status -> runOnUiThread(() -> {
            if(status != TextToSpeech.SUCCESS || tts == null){
                ttsReady=false;
                ttsInfo="系统语音不可用，请到手机设置安装英语（美国）语音引擎。";
                event("tts_error", ttsInfo, null);
                return;
            }
            int language = tts.setLanguage(Locale.US);
            if(language < 0){
                ttsReady=false;
                ttsInfo="缺少 English (United States) 语言包，请在安卓文字转语音设置中安装。";
                event("tts_error", ttsInfo, null);
                return;
            }
            Voice best=null;
            Set<Voice> offered=tts.getVoices();
            if(offered!=null)for(Voice candidate : offered){
                if(candidate==null || candidate.getLocale()==null)continue;
                Locale loc=candidate.getLocale();
                if(!"en".equalsIgnoreCase(loc.getLanguage()) || !"US".equalsIgnoreCase(loc.getCountry()))continue;
                if(candidate.isNetworkConnectionRequired())continue;
                if(best==null || candidate.getQuality()>best.getQuality())best=candidate;
            }
            if(best!=null)tts.setVoice(best);
            else if(tts.getVoice()==null || tts.getVoice().isNetworkConnectionRequired()){
                ttsReady=false;
                ttsInfo="没有可离线播放的美式英语语音。请在安卓文字转语音设置下载 English (United States) 离线语音。";
                event("tts_error", ttsInfo, null);
                return;
            }
            tts.setSpeechRate(0.94f);
            tts.setPitch(1.04f);
            ttsReady=true;
            ttsInfo="✅ 已启用本机离线 English (United States) AI 语音，可播放解释、例句、鼓励语。";
            event("tts_ready",ttsInfo,null);
        }));
    }
    private void speakOffline(String text){
        String normalized=text==null?"":text.trim();
        if(normalized.isEmpty() || normalized.length()>800){event("tts_error","朗读内容不能为空或过长",null);return;}
        if(!ttsReady || tts==null){event("tts_error",ttsInfo,null);return;}
        synchronized(mediaLock){
            if(playing!=null){playing.release();playing=null;}
        }
        int status=tts.speak(normalized, TextToSpeech.QUEUE_FLUSH, null, "phonics-"+System.nanoTime());
        if(status==TextToSpeech.ERROR)event("tts_error","手机的英语语音引擎朗读失败，请检查离线语音包",null);
    }

    private boolean isKey(String key) {return key!=null && KEY_PATTERN.matcher(key).matches();}
    private File clipFile(String key) {
        if (!isKey(key))return null;
        String stem=key.replace(':','_');
        for(String ext:EXTENSIONS){File f=new File(clipDir,stem+"."+ext);if(f.isFile())return f;}
        return null;
    }
    private String ext(String name){
        if(name==null)return "";
        int i=name.lastIndexOf('.');
        if(i<0)return "";
        String s=name.substring(i+1).toLowerCase(Locale.US);
        for(String ext:EXTENSIONS)if(ext.equals(s))return ext;
        return "";
    }
    private String fileName(Uri uri){
        String result="";
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(c!=null && c.moveToFirst())result=c.getString(0);
        }catch(Exception ignored){}
        if(result==null||result.isEmpty())result=uri.getLastPathSegment();
        return result==null?"":result;
    }
    private String keyFromFilename(String filename){
        Matcher m=NAMED_PATTERN.matcher(filename);
        if(m.matches()){
            String key=m.group(1).toLowerCase(Locale.US)+":"+m.group(2).toLowerCase(Locale.US);
            return isKey(key)?key:null;
        }
        m=COMMONS_PATTERN.matcher(filename);
        if(m.matches()){
            String key="word:"+m.group(1).toLowerCase(Locale.US);
            return isKey(key)?key:null;
        }
        return null;
    }
    private String importOne(Uri uri, String key) throws Exception {
        if(!isKey(key))throw new IllegalArgumentException("无效单词标记："+key);
        String filename=fileName(uri);
        String extension=ext(filename);
        if(extension.isEmpty())throw new IllegalArgumentException("请选择 .ogg / .mp3 / .wav / .m4a / .aac 音频文件");
        File tmp=new File(clipDir,"_import.tmp");
        long total=0;
        try(InputStream in=getContentResolver().openInputStream(uri);
            FileOutputStream out=new FileOutputStream(tmp)) {
            if(in==null)throw new IllegalArgumentException("无法读取所选文件");
            byte[] buf=new byte[16384];
            int n;
            while((n=in.read(buf))!=-1){
                total+=n;
                if(total>MAX_CLIP)throw new IllegalArgumentException("音频文件大于6MB");
                out.write(buf,0,n);
            }
            out.flush();
        }catch(Exception ex){tmp.delete();throw ex;}
        if(total<100){tmp.delete();throw new IllegalArgumentException("文件过小或为空");}
        String stem=key.replace(':','_');
        File finalFile=new File(clipDir,stem+"."+extension);
        File old=clipFile(key);
        if(old!=null && !old.equals(finalFile))old.delete();
        if(finalFile.exists()&&!finalFile.delete()){tmp.delete();throw new Exception("无法覆盖旧录音");}
        if(!tmp.renameTo(finalFile)){tmp.delete();throw new Exception("无法保存录音文件");}
        return filename;
    }

    private void event(String status,String msg,String key){
        String js="window.onNativeAudioEvent && window.onNativeAudioEvent("+JSONObject.quote(status)+","+JSONObject.quote(msg)+","+JSONObject.quote(key==null?"":key)+")";
        runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript(js,null);});
    }
    private void launchAudioChooser(String key,boolean bulk){
        if(!bulk && !isKey(key)){event("error","导入目标单词无效",key);return;}
        try {
            bulkPending=bulk;
            singlePendingKey=key;
            Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("*/*");
            pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,bulk);
            pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(pick,REQUEST_NATIVE_AUDIO);
        }catch(Exception ex){event("error","无法打开文件选择器："+ex.getClass().getSimpleName(),key);}
    }
    private List<Uri> picked(Intent intent){
        List<Uri> result=new ArrayList<>();
        if(intent==null)return result;
        ClipData clips=intent.getClipData();
        if(clips!=null){for(int i=0;i<clips.getItemCount();i++)result.add(clips.getItemAt(i).getUri());}
        else if(intent.getData()!=null)result.add(intent.getData());
        return result;
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQUEST_WEB_FILE){
            if(legacyCallback!=null){
                List<Uri> uris=resultCode==RESULT_OK?picked(data):new ArrayList<>();
                legacyCallback.onReceiveValue(uris.isEmpty()?null:uris.toArray(new Uri[0]));
                legacyCallback=null;
            }
            return;
        }
        if(requestCode!=REQUEST_NATIVE_AUDIO)return;
        if(resultCode!=RESULT_OK){event("cancel","已取消选择录音",null);return;}
        List<Uri> uris=picked(data);
        final boolean bulk=bulkPending;
        final String key=singlePendingKey;
        if(uris.isEmpty()){event("error","没有读取到所选文件",key);return;}
        new Thread(()->{
            int ok=0;String lastError=null;String lastKey=null;
            for(Uri uri:uris){
                String target=bulk?keyFromFilename(fileName(uri)):key;
                if(target==null){lastError="无法识别文件名："+fileName(uri);continue;}
                try{importOne(uri,target);ok++;lastKey=target;}
                catch(Exception e){lastError=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();}
            }
            if(bulk){
                String msg="成功导入 "+ok+" / "+uris.size()+" 段真人录音"+(lastError==null?"":"；失败原因："+lastError);
                event("batchdone",msg,null);
            }else if(ok==1){
                event("imported","录音已保存，正在试听",lastKey);
            }else event("error","导入失败："+(lastError==null?"无法读取文件":lastError),key);
        }).start();
    }
    private void playNative(String key){
        if(tts!=null)tts.stop();
        File f=clipFile(key);
        if(f==null){event("error","未找到这段真人录音",key);return;}
        synchronized(mediaLock){
            try{
                if(playing!=null){playing.release();playing=null;}
                MediaPlayer p=new MediaPlayer();
                try(FileInputStream in=new FileInputStream(f)) {p.setDataSource(in.getFD());p.prepare();}
                p.setOnCompletionListener(done->{synchronized(mediaLock){if(playing==done)playing=null;}done.release();});
                p.setOnErrorListener((broken,what,extra)->{
                    synchronized(mediaLock){if(playing==broken)playing=null;}
                    broken.release();
                    event("error","真人录音无法播放；请检查音频编码，错误 "+what,key);
                    return true;
                });
                playing=p;
                p.start();
            }catch(Exception ex){
                if(playing!=null){playing.release();playing=null;}
                event("error","播放失败："+(ex.getMessage()==null?ex.getClass().getSimpleName():ex.getMessage()),key);
            }
        }
    }
    private final class NativeVoice {
        @JavascriptInterface public boolean hasClip(String key){return clipFile(key)!=null;}
        @JavascriptInterface public void speakText(String text){runOnUiThread(()->speakOffline(text));}
        @JavascriptInterface public boolean isTtsReady(){return ttsReady;}
        @JavascriptInterface public String getTtsInfo(){return ttsInfo;}
        @JavascriptInterface public void playClip(String key){runOnUiThread(()->playNative(key));}
        @JavascriptInterface public void requestImport(String key){runOnUiThread(()->launchAudioChooser(key,false));}
        @JavascriptInterface public void requestBulkImport(){runOnUiThread(()->launchAudioChooser(null,true));}
    }
    @Override protected void onDestroy(){
        if(tts!=null){tts.stop();tts.shutdown();tts=null;}
        synchronized(mediaLock){if(playing!=null){playing.release();playing=null;}}
        if(webView!=null){webView.destroy();webView=null;}
        super.onDestroy();
    }
}
